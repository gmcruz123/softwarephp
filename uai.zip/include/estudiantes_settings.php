<?php
require_once(getabspath("classes/cipherer.php"));




$tdataestudiantes = array();
	$tdataestudiantes[".truncateText"] = true;
	$tdataestudiantes[".NumberOfChars"] = 80;
	$tdataestudiantes[".ShortName"] = "estudiantes";
	$tdataestudiantes[".OwnerID"] = "";
	$tdataestudiantes[".OriginalTable"] = "estudiantes";

//	field labels
$fieldLabelsestudiantes = array();
$fieldToolTipsestudiantes = array();
$pageTitlesestudiantes = array();
$placeHoldersestudiantes = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsestudiantes["English"] = array();
	$fieldToolTipsestudiantes["English"] = array();
	$placeHoldersestudiantes["English"] = array();
	$pageTitlesestudiantes["English"] = array();
	$fieldLabelsestudiantes["English"]["ID_ESTUDIANTE"] = "ID ESTUDIANTE";
	$fieldToolTipsestudiantes["English"]["ID_ESTUDIANTE"] = "";
	$placeHoldersestudiantes["English"]["ID_ESTUDIANTE"] = "";
	$fieldLabelsestudiantes["English"]["NOMBRE"] = "Nombre Completo";
	$fieldToolTipsestudiantes["English"]["NOMBRE"] = "";
	$placeHoldersestudiantes["English"]["NOMBRE"] = "";
	$fieldLabelsestudiantes["English"]["FECHANACIMIENTO"] = "Fecha de nacimiento";
	$fieldToolTipsestudiantes["English"]["FECHANACIMIENTO"] = "";
	$placeHoldersestudiantes["English"]["FECHANACIMIENTO"] = "";
	$fieldLabelsestudiantes["English"]["DIRECCION"] = "Direccion";
	$fieldToolTipsestudiantes["English"]["DIRECCION"] = "";
	$placeHoldersestudiantes["English"]["DIRECCION"] = "";
	$fieldLabelsestudiantes["English"]["TELEFONO"] = "Telefono";
	$fieldToolTipsestudiantes["English"]["TELEFONO"] = "";
	$placeHoldersestudiantes["English"]["TELEFONO"] = "";
	$fieldLabelsestudiantes["English"]["DIAGNOSTICO"] = "Diagnostico";
	$fieldToolTipsestudiantes["English"]["DIAGNOSTICO"] = "";
	$placeHoldersestudiantes["English"]["DIAGNOSTICO"] = "";
	$fieldLabelsestudiantes["English"]["NOMBREDELPADRE"] = "Nombre del Padre";
	$fieldToolTipsestudiantes["English"]["NOMBREDELPADRE"] = "";
	$placeHoldersestudiantes["English"]["NOMBREDELPADRE"] = "";
	$fieldLabelsestudiantes["English"]["NOMBREDELAMADRE"] = "Nombre de la Madre";
	$fieldToolTipsestudiantes["English"]["NOMBREDELAMADRE"] = "";
	$placeHoldersestudiantes["English"]["NOMBREDELAMADRE"] = "";
	$fieldLabelsestudiantes["English"]["NOMBREACUDIENTE"] = "Nombre del Acudiente";
	$fieldToolTipsestudiantes["English"]["NOMBREACUDIENTE"] = "";
	$placeHoldersestudiantes["English"]["NOMBREACUDIENTE"] = "";
	$fieldLabelsestudiantes["English"]["HABILIDADES"] = "Habilidades";
	$fieldToolTipsestudiantes["English"]["HABILIDADES"] = "";
	$placeHoldersestudiantes["English"]["HABILIDADES"] = "";
	$fieldLabelsestudiantes["English"]["LIMITACIONES"] = "Limitaciones";
	$fieldToolTipsestudiantes["English"]["LIMITACIONES"] = "";
	$placeHoldersestudiantes["English"]["LIMITACIONES"] = "";
	$fieldLabelsestudiantes["English"]["DOCENTEACARGO"] = "Docente a Cargo";
	$fieldToolTipsestudiantes["English"]["DOCENTEACARGO"] = "";
	$placeHoldersestudiantes["English"]["DOCENTEACARGO"] = "";
	$fieldLabelsestudiantes["English"]["FOTODEPERFIL"] = "Foto de Perfil";
	$fieldToolTipsestudiantes["English"]["FOTODEPERFIL"] = "";
	$placeHoldersestudiantes["English"]["FOTODEPERFIL"] = "";
	if (count($fieldToolTipsestudiantes["English"]))
		$tdataestudiantes[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="")
{
	$fieldLabelsestudiantes[""] = array();
	$fieldToolTipsestudiantes[""] = array();
	$placeHoldersestudiantes[""] = array();
	$pageTitlesestudiantes[""] = array();
	$fieldLabelsestudiantes[""]["ID_ESTUDIANTE"] = "ID ESTUDIANTE";
	$fieldToolTipsestudiantes[""]["ID_ESTUDIANTE"] = "";
	$placeHoldersestudiantes[""]["ID_ESTUDIANTE"] = "";
	$fieldLabelsestudiantes[""]["NOMBRE"] = "NOMBRE";
	$fieldToolTipsestudiantes[""]["NOMBRE"] = "";
	$placeHoldersestudiantes[""]["NOMBRE"] = "";
	$fieldLabelsestudiantes[""]["FECHANACIMIENTO"] = "FECHANACIMIENTO";
	$fieldToolTipsestudiantes[""]["FECHANACIMIENTO"] = "";
	$placeHoldersestudiantes[""]["FECHANACIMIENTO"] = "";
	$fieldLabelsestudiantes[""]["DIRECCION"] = "DIRECCION";
	$fieldToolTipsestudiantes[""]["DIRECCION"] = "";
	$placeHoldersestudiantes[""]["DIRECCION"] = "";
	$fieldLabelsestudiantes[""]["TELEFONO"] = "TELEFONO";
	$fieldToolTipsestudiantes[""]["TELEFONO"] = "";
	$placeHoldersestudiantes[""]["TELEFONO"] = "";
	$fieldLabelsestudiantes[""]["DIAGNOSTICO"] = "DIAGNOSTICO";
	$fieldToolTipsestudiantes[""]["DIAGNOSTICO"] = "";
	$placeHoldersestudiantes[""]["DIAGNOSTICO"] = "";
	$fieldLabelsestudiantes[""]["NOMBREDELPADRE"] = "NOMBREDELPADRE";
	$fieldToolTipsestudiantes[""]["NOMBREDELPADRE"] = "";
	$placeHoldersestudiantes[""]["NOMBREDELPADRE"] = "";
	$fieldLabelsestudiantes[""]["NOMBREDELAMADRE"] = "NOMBREDELAMADRE";
	$fieldToolTipsestudiantes[""]["NOMBREDELAMADRE"] = "";
	$placeHoldersestudiantes[""]["NOMBREDELAMADRE"] = "";
	$fieldLabelsestudiantes[""]["NOMBREACUDIENTE"] = "NOMBREACUDIENTE";
	$fieldToolTipsestudiantes[""]["NOMBREACUDIENTE"] = "";
	$placeHoldersestudiantes[""]["NOMBREACUDIENTE"] = "";
	$fieldLabelsestudiantes[""]["HABILIDADES"] = "HABILIDADES";
	$fieldToolTipsestudiantes[""]["HABILIDADES"] = "";
	$placeHoldersestudiantes[""]["HABILIDADES"] = "";
	$fieldLabelsestudiantes[""]["LIMITACIONES"] = "LIMITACIONES";
	$fieldToolTipsestudiantes[""]["LIMITACIONES"] = "";
	$placeHoldersestudiantes[""]["LIMITACIONES"] = "";
	$fieldLabelsestudiantes[""]["DOCENTEACARGO"] = "DOCENTEACARGO";
	$fieldToolTipsestudiantes[""]["DOCENTEACARGO"] = "";
	$placeHoldersestudiantes[""]["DOCENTEACARGO"] = "";
	$fieldLabelsestudiantes[""]["FOTODEPERFIL"] = "FOTODEPERFIL";
	$fieldToolTipsestudiantes[""]["FOTODEPERFIL"] = "";
	$placeHoldersestudiantes[""]["FOTODEPERFIL"] = "";
	if (count($fieldToolTipsestudiantes[""]))
		$tdataestudiantes[".isUseToolTips"] = true;
}


	$tdataestudiantes[".NCSearch"] = true;



$tdataestudiantes[".shortTableName"] = "estudiantes";
$tdataestudiantes[".nSecOptions"] = 0;
$tdataestudiantes[".recsPerRowPrint"] = 1;
$tdataestudiantes[".mainTableOwnerID"] = "";
$tdataestudiantes[".moveNext"] = 1;
$tdataestudiantes[".entityType"] = 0;

$tdataestudiantes[".strOriginalTableName"] = "estudiantes";

	



$tdataestudiantes[".showAddInPopup"] = true;

$tdataestudiantes[".showEditInPopup"] = true;

$tdataestudiantes[".showViewInPopup"] = true;

//page's base css files names
$popupPagesLayoutNames = array();
						
	;
$popupPagesLayoutNames["add"] = "add_bootstrap_2col";
						
	;
$popupPagesLayoutNames["edit"] = "edit_bootstrap";
						
	;
$popupPagesLayoutNames["view"] = "view_bootstrap_2col";
$tdataestudiantes[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdataestudiantes[".fieldsForRegister"] = array();

$tdataestudiantes[".listAjax"] = false;

	$tdataestudiantes[".audit"] = false;

	$tdataestudiantes[".locking"] = false;

$tdataestudiantes[".edit"] = true;
$tdataestudiantes[".afterEditAction"] = 1;
$tdataestudiantes[".closePopupAfterEdit"] = 1;
$tdataestudiantes[".afterEditActionDetTable"] = "";

$tdataestudiantes[".add"] = true;
$tdataestudiantes[".afterAddAction"] = 1;
$tdataestudiantes[".closePopupAfterAdd"] = 1;
$tdataestudiantes[".afterAddActionDetTable"] = "";

$tdataestudiantes[".list"] = true;



$tdataestudiantes[".reorderRecordsByHeader"] = true;


$tdataestudiantes[".exportFormatting"] = 2;
$tdataestudiantes[".exportDelimiter"] = ",";
		
$tdataestudiantes[".view"] = true;

$tdataestudiantes[".import"] = true;

$tdataestudiantes[".exportTo"] = true;

$tdataestudiantes[".printFriendly"] = true;

$tdataestudiantes[".delete"] = true;

$tdataestudiantes[".showSimpleSearchOptions"] = false;

// Allow Show/Hide Fields in GRID
$tdataestudiantes[".allowShowHideFields"] = false;
//

// Allow Fields Reordering in GRID
$tdataestudiantes[".allowFieldsReordering"] = false;
//

// search Saving settings
$tdataestudiantes[".searchSaving"] = false;
//

$tdataestudiantes[".showSearchPanel"] = true;
		$tdataestudiantes[".flexibleSearch"] = true;

$tdataestudiantes[".isUseAjaxSuggest"] = true;

$tdataestudiantes[".rowHighlite"] = true;





$tdataestudiantes[".ajaxCodeSnippetAdded"] = false;

$tdataestudiantes[".buttonsAdded"] = false;

$tdataestudiantes[".addPageEvents"] = false;

// use timepicker for search panel
$tdataestudiantes[".isUseTimeForSearch"] = false;





$tdataestudiantes[".allSearchFields"] = array();
$tdataestudiantes[".filterFields"] = array();
$tdataestudiantes[".requiredSearchFields"] = array();

$tdataestudiantes[".allSearchFields"][] = "ID_ESTUDIANTE";
	$tdataestudiantes[".allSearchFields"][] = "NOMBRE";
	$tdataestudiantes[".allSearchFields"][] = "FECHANACIMIENTO";
	$tdataestudiantes[".allSearchFields"][] = "DIRECCION";
	$tdataestudiantes[".allSearchFields"][] = "TELEFONO";
	$tdataestudiantes[".allSearchFields"][] = "DIAGNOSTICO";
	$tdataestudiantes[".allSearchFields"][] = "NOMBREDELPADRE";
	$tdataestudiantes[".allSearchFields"][] = "NOMBREDELAMADRE";
	$tdataestudiantes[".allSearchFields"][] = "NOMBREACUDIENTE";
	$tdataestudiantes[".allSearchFields"][] = "HABILIDADES";
	$tdataestudiantes[".allSearchFields"][] = "LIMITACIONES";
	$tdataestudiantes[".allSearchFields"][] = "DOCENTEACARGO";
	$tdataestudiantes[".allSearchFields"][] = "FOTODEPERFIL";
	

$tdataestudiantes[".googleLikeFields"] = array();
$tdataestudiantes[".googleLikeFields"][] = "ID_ESTUDIANTE";
$tdataestudiantes[".googleLikeFields"][] = "NOMBRE";
$tdataestudiantes[".googleLikeFields"][] = "FECHANACIMIENTO";
$tdataestudiantes[".googleLikeFields"][] = "DIRECCION";
$tdataestudiantes[".googleLikeFields"][] = "TELEFONO";
$tdataestudiantes[".googleLikeFields"][] = "DIAGNOSTICO";
$tdataestudiantes[".googleLikeFields"][] = "NOMBREDELPADRE";
$tdataestudiantes[".googleLikeFields"][] = "NOMBREDELAMADRE";
$tdataestudiantes[".googleLikeFields"][] = "NOMBREACUDIENTE";
$tdataestudiantes[".googleLikeFields"][] = "HABILIDADES";
$tdataestudiantes[".googleLikeFields"][] = "LIMITACIONES";
$tdataestudiantes[".googleLikeFields"][] = "DOCENTEACARGO";
$tdataestudiantes[".googleLikeFields"][] = "FOTODEPERFIL";


$tdataestudiantes[".advSearchFields"] = array();
$tdataestudiantes[".advSearchFields"][] = "ID_ESTUDIANTE";
$tdataestudiantes[".advSearchFields"][] = "NOMBRE";
$tdataestudiantes[".advSearchFields"][] = "FECHANACIMIENTO";
$tdataestudiantes[".advSearchFields"][] = "DIRECCION";
$tdataestudiantes[".advSearchFields"][] = "TELEFONO";
$tdataestudiantes[".advSearchFields"][] = "DIAGNOSTICO";
$tdataestudiantes[".advSearchFields"][] = "NOMBREDELPADRE";
$tdataestudiantes[".advSearchFields"][] = "NOMBREDELAMADRE";
$tdataestudiantes[".advSearchFields"][] = "NOMBREACUDIENTE";
$tdataestudiantes[".advSearchFields"][] = "HABILIDADES";
$tdataestudiantes[".advSearchFields"][] = "LIMITACIONES";
$tdataestudiantes[".advSearchFields"][] = "DOCENTEACARGO";
$tdataestudiantes[".advSearchFields"][] = "FOTODEPERFIL";

$tdataestudiantes[".tableType"] = "list";

$tdataestudiantes[".printerPageOrientation"] = 0;
$tdataestudiantes[".nPrinterPageScale"] = 100;

$tdataestudiantes[".nPrinterSplitRecords"] = 40;

$tdataestudiantes[".nPrinterPDFSplitRecords"] = 40;



$tdataestudiantes[".geocodingEnabled"] = false;





$tdataestudiantes[".listGridLayout"] = 3;





// view page pdf

// print page pdf


$tdataestudiantes[".pageSize"] = 20;

$tdataestudiantes[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdataestudiantes[".strOrderBy"] = $tstrOrderBy;

$tdataestudiantes[".orderindexes"] = array();

$tdataestudiantes[".sqlHead"] = "SELECT ID_ESTUDIANTE,  	NOMBRE,  	FECHANACIMIENTO,  	DIRECCION,  	TELEFONO,  	DIAGNOSTICO,  	NOMBREDELPADRE,  	NOMBREDELAMADRE,  	NOMBREACUDIENTE,  	HABILIDADES,  	LIMITACIONES,  	DOCENTEACARGO,  	FOTODEPERFIL";
$tdataestudiantes[".sqlFrom"] = "FROM estudiantes";
$tdataestudiantes[".sqlWhereExpr"] = "";
$tdataestudiantes[".sqlTail"] = "";












//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataestudiantes[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataestudiantes[".arrGroupsPerPage"] = $arrGPP;

$tdataestudiantes[".highlightSearchResults"] = true;

$tableKeysestudiantes = array();
$tableKeysestudiantes[] = "ID_ESTUDIANTE";
$tdataestudiantes[".Keys"] = $tableKeysestudiantes;

$tdataestudiantes[".listFields"] = array();
$tdataestudiantes[".listFields"][] = "FOTODEPERFIL";
$tdataestudiantes[".listFields"][] = "DOCENTEACARGO";
$tdataestudiantes[".listFields"][] = "NOMBRE";
$tdataestudiantes[".listFields"][] = "FECHANACIMIENTO";
$tdataestudiantes[".listFields"][] = "DIAGNOSTICO";
$tdataestudiantes[".listFields"][] = "LIMITACIONES";
$tdataestudiantes[".listFields"][] = "HABILIDADES";

$tdataestudiantes[".hideMobileList"] = array();


$tdataestudiantes[".viewFields"] = array();
$tdataestudiantes[".viewFields"][] = "NOMBRE";
$tdataestudiantes[".viewFields"][] = "FECHANACIMIENTO";
$tdataestudiantes[".viewFields"][] = "DIRECCION";
$tdataestudiantes[".viewFields"][] = "TELEFONO";
$tdataestudiantes[".viewFields"][] = "DIAGNOSTICO";
$tdataestudiantes[".viewFields"][] = "NOMBREDELPADRE";
$tdataestudiantes[".viewFields"][] = "NOMBREDELAMADRE";
$tdataestudiantes[".viewFields"][] = "NOMBREACUDIENTE";
$tdataestudiantes[".viewFields"][] = "HABILIDADES";
$tdataestudiantes[".viewFields"][] = "LIMITACIONES";
$tdataestudiantes[".viewFields"][] = "DOCENTEACARGO";
$tdataestudiantes[".viewFields"][] = "FOTODEPERFIL";

$tdataestudiantes[".addFields"] = array();
$tdataestudiantes[".addFields"][] = "DOCENTEACARGO";
$tdataestudiantes[".addFields"][] = "NOMBRE";
$tdataestudiantes[".addFields"][] = "FECHANACIMIENTO";
$tdataestudiantes[".addFields"][] = "DIRECCION";
$tdataestudiantes[".addFields"][] = "TELEFONO";
$tdataestudiantes[".addFields"][] = "NOMBREDELPADRE";
$tdataestudiantes[".addFields"][] = "NOMBREDELAMADRE";
$tdataestudiantes[".addFields"][] = "NOMBREACUDIENTE";
$tdataestudiantes[".addFields"][] = "HABILIDADES";
$tdataestudiantes[".addFields"][] = "DIAGNOSTICO";
$tdataestudiantes[".addFields"][] = "LIMITACIONES";
$tdataestudiantes[".addFields"][] = "FOTODEPERFIL";

$tdataestudiantes[".masterListFields"] = array();
$tdataestudiantes[".masterListFields"][] = "ID_ESTUDIANTE";
$tdataestudiantes[".masterListFields"][] = "NOMBRE";
$tdataestudiantes[".masterListFields"][] = "FECHANACIMIENTO";
$tdataestudiantes[".masterListFields"][] = "DIRECCION";
$tdataestudiantes[".masterListFields"][] = "TELEFONO";
$tdataestudiantes[".masterListFields"][] = "DIAGNOSTICO";
$tdataestudiantes[".masterListFields"][] = "NOMBREDELPADRE";
$tdataestudiantes[".masterListFields"][] = "NOMBREDELAMADRE";
$tdataestudiantes[".masterListFields"][] = "NOMBREACUDIENTE";
$tdataestudiantes[".masterListFields"][] = "HABILIDADES";
$tdataestudiantes[".masterListFields"][] = "LIMITACIONES";
$tdataestudiantes[".masterListFields"][] = "DOCENTEACARGO";
$tdataestudiantes[".masterListFields"][] = "FOTODEPERFIL";

$tdataestudiantes[".inlineAddFields"] = array();

$tdataestudiantes[".editFields"] = array();
$tdataestudiantes[".editFields"][] = "NOMBRE";
$tdataestudiantes[".editFields"][] = "FECHANACIMIENTO";
$tdataestudiantes[".editFields"][] = "DIRECCION";
$tdataestudiantes[".editFields"][] = "TELEFONO";
$tdataestudiantes[".editFields"][] = "DIAGNOSTICO";
$tdataestudiantes[".editFields"][] = "NOMBREDELPADRE";
$tdataestudiantes[".editFields"][] = "NOMBREDELAMADRE";
$tdataestudiantes[".editFields"][] = "NOMBREACUDIENTE";
$tdataestudiantes[".editFields"][] = "HABILIDADES";
$tdataestudiantes[".editFields"][] = "LIMITACIONES";
$tdataestudiantes[".editFields"][] = "DOCENTEACARGO";
$tdataestudiantes[".editFields"][] = "FOTODEPERFIL";

$tdataestudiantes[".inlineEditFields"] = array();

$tdataestudiantes[".updateSelectedFields"] = array();
$tdataestudiantes[".updateSelectedFields"][] = "NOMBRE";
$tdataestudiantes[".updateSelectedFields"][] = "FECHANACIMIENTO";
$tdataestudiantes[".updateSelectedFields"][] = "DIRECCION";
$tdataestudiantes[".updateSelectedFields"][] = "TELEFONO";
$tdataestudiantes[".updateSelectedFields"][] = "DIAGNOSTICO";
$tdataestudiantes[".updateSelectedFields"][] = "NOMBREDELPADRE";
$tdataestudiantes[".updateSelectedFields"][] = "NOMBREDELAMADRE";
$tdataestudiantes[".updateSelectedFields"][] = "NOMBREACUDIENTE";
$tdataestudiantes[".updateSelectedFields"][] = "HABILIDADES";
$tdataestudiantes[".updateSelectedFields"][] = "LIMITACIONES";
$tdataestudiantes[".updateSelectedFields"][] = "DOCENTEACARGO";
$tdataestudiantes[".updateSelectedFields"][] = "FOTODEPERFIL";


$tdataestudiantes[".exportFields"] = array();
$tdataestudiantes[".exportFields"][] = "NOMBRE";
$tdataestudiantes[".exportFields"][] = "FECHANACIMIENTO";
$tdataestudiantes[".exportFields"][] = "DIRECCION";
$tdataestudiantes[".exportFields"][] = "TELEFONO";
$tdataestudiantes[".exportFields"][] = "DIAGNOSTICO";
$tdataestudiantes[".exportFields"][] = "NOMBREDELPADRE";
$tdataestudiantes[".exportFields"][] = "NOMBREDELAMADRE";
$tdataestudiantes[".exportFields"][] = "NOMBREACUDIENTE";
$tdataestudiantes[".exportFields"][] = "HABILIDADES";
$tdataestudiantes[".exportFields"][] = "LIMITACIONES";
$tdataestudiantes[".exportFields"][] = "DOCENTEACARGO";
$tdataestudiantes[".exportFields"][] = "FOTODEPERFIL";

$tdataestudiantes[".importFields"] = array();
$tdataestudiantes[".importFields"][] = "NOMBRE";
$tdataestudiantes[".importFields"][] = "FECHANACIMIENTO";
$tdataestudiantes[".importFields"][] = "DIRECCION";
$tdataestudiantes[".importFields"][] = "TELEFONO";
$tdataestudiantes[".importFields"][] = "DIAGNOSTICO";
$tdataestudiantes[".importFields"][] = "NOMBREDELPADRE";
$tdataestudiantes[".importFields"][] = "NOMBREDELAMADRE";
$tdataestudiantes[".importFields"][] = "NOMBREACUDIENTE";
$tdataestudiantes[".importFields"][] = "HABILIDADES";
$tdataestudiantes[".importFields"][] = "LIMITACIONES";
$tdataestudiantes[".importFields"][] = "DOCENTEACARGO";
$tdataestudiantes[".importFields"][] = "FOTODEPERFIL";

$tdataestudiantes[".printFields"] = array();
$tdataestudiantes[".printFields"][] = "NOMBRE";
$tdataestudiantes[".printFields"][] = "FECHANACIMIENTO";
$tdataestudiantes[".printFields"][] = "DIRECCION";
$tdataestudiantes[".printFields"][] = "TELEFONO";
$tdataestudiantes[".printFields"][] = "DIAGNOSTICO";
$tdataestudiantes[".printFields"][] = "NOMBREDELPADRE";
$tdataestudiantes[".printFields"][] = "NOMBREDELAMADRE";
$tdataestudiantes[".printFields"][] = "NOMBREACUDIENTE";
$tdataestudiantes[".printFields"][] = "HABILIDADES";
$tdataestudiantes[".printFields"][] = "LIMITACIONES";
$tdataestudiantes[".printFields"][] = "DOCENTEACARGO";
$tdataestudiantes[".printFields"][] = "FOTODEPERFIL";


//	ID_ESTUDIANTE
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "ID_ESTUDIANTE";
	$fdata["GoodName"] = "ID_ESTUDIANTE";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("estudiantes","ID_ESTUDIANTE");
	$fdata["FieldType"] = 3;

	
		$fdata["AutoInc"] = true;

	
			
	
	
	
	
	
	

	
		$fdata["bAdvancedSearch"] = true;

	
	
		$fdata["strField"] = "ID_ESTUDIANTE";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "ID_ESTUDIANTE";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


		$edata["IsRequired"] = true;

	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataestudiantes["ID_ESTUDIANTE"] = $fdata;
//	NOMBRE
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "NOMBRE";
	$fdata["GoodName"] = "NOMBRE";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("estudiantes","NOMBRE");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

	
		$fdata["bEditPage"] = true;

	
		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "NOMBRE";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "NOMBRE";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataestudiantes["NOMBRE"] = $fdata;
//	FECHANACIMIENTO
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "FECHANACIMIENTO";
	$fdata["GoodName"] = "FECHANACIMIENTO";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("estudiantes","FECHANACIMIENTO");
	$fdata["FieldType"] = 135;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

	
		$fdata["bEditPage"] = true;

	
		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "FECHANACIMIENTO";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "FECHANACIMIENTO";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Short Date");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Date");

	
	
		
	


		$edata["IsRequired"] = true;

	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
		$edata["DateEditType"] = 2;
	$edata["InitialYearFactor"] = 1;
	$edata["LastYearFactor"] = 1;

	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between", EMPTY_SEARCH, NOT_EMPTY );
// the end of search options settings




	$tdataestudiantes["FECHANACIMIENTO"] = $fdata;
//	DIRECCION
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "DIRECCION";
	$fdata["GoodName"] = "DIRECCION";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("estudiantes","DIRECCION");
	$fdata["FieldType"] = 200;

	
	
	
			
	
		$fdata["bAddPage"] = true;

	
		$fdata["bEditPage"] = true;

	
		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "DIRECCION";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "DIRECCION";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataestudiantes["DIRECCION"] = $fdata;
//	TELEFONO
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "TELEFONO";
	$fdata["GoodName"] = "TELEFONO";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("estudiantes","TELEFONO");
	$fdata["FieldType"] = 3;

	
	
	
			
	
		$fdata["bAddPage"] = true;

	
		$fdata["bEditPage"] = true;

	
		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "TELEFONO";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "TELEFONO";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


		$edata["IsRequired"] = true;

	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "number";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataestudiantes["TELEFONO"] = $fdata;
//	DIAGNOSTICO
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "DIAGNOSTICO";
	$fdata["GoodName"] = "DIAGNOSTICO";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("estudiantes","DIAGNOSTICO");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

	
		$fdata["bEditPage"] = true;

	
		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "DIAGNOSTICO";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "DIAGNOSTICO";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text area");

	
	
		
	


		$edata["IsRequired"] = true;

	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
				$edata["nRows"] = 100;
			$edata["nCols"] = 200;

	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataestudiantes["DIAGNOSTICO"] = $fdata;
//	NOMBREDELPADRE
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "NOMBREDELPADRE";
	$fdata["GoodName"] = "NOMBREDELPADRE";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("estudiantes","NOMBREDELPADRE");
	$fdata["FieldType"] = 200;

	
	
	
			
	
		$fdata["bAddPage"] = true;

	
		$fdata["bEditPage"] = true;

	
		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "NOMBREDELPADRE";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "NOMBREDELPADRE";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataestudiantes["NOMBREDELPADRE"] = $fdata;
//	NOMBREDELAMADRE
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 8;
	$fdata["strName"] = "NOMBREDELAMADRE";
	$fdata["GoodName"] = "NOMBREDELAMADRE";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("estudiantes","NOMBREDELAMADRE");
	$fdata["FieldType"] = 200;

	
	
	
			
	
		$fdata["bAddPage"] = true;

	
		$fdata["bEditPage"] = true;

	
		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "NOMBREDELAMADRE";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "NOMBREDELAMADRE";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataestudiantes["NOMBREDELAMADRE"] = $fdata;
//	NOMBREACUDIENTE
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 9;
	$fdata["strName"] = "NOMBREACUDIENTE";
	$fdata["GoodName"] = "NOMBREACUDIENTE";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("estudiantes","NOMBREACUDIENTE");
	$fdata["FieldType"] = 200;

	
	
	
			
	
		$fdata["bAddPage"] = true;

	
		$fdata["bEditPage"] = true;

	
		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "NOMBREACUDIENTE";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "NOMBREACUDIENTE";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataestudiantes["NOMBREACUDIENTE"] = $fdata;
//	HABILIDADES
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 10;
	$fdata["strName"] = "HABILIDADES";
	$fdata["GoodName"] = "HABILIDADES";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("estudiantes","HABILIDADES");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

	
		$fdata["bEditPage"] = true;

	
		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "HABILIDADES";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "HABILIDADES";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text area");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
				$edata["nRows"] = 100;
			$edata["nCols"] = 200;

	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataestudiantes["HABILIDADES"] = $fdata;
//	LIMITACIONES
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 11;
	$fdata["strName"] = "LIMITACIONES";
	$fdata["GoodName"] = "LIMITACIONES";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("estudiantes","LIMITACIONES");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

	
		$fdata["bEditPage"] = true;

	
		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "LIMITACIONES";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "LIMITACIONES";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text area");

	
	
		
	


		$edata["IsRequired"] = true;

	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
				$edata["nRows"] = 100;
			$edata["nCols"] = 200;

	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataestudiantes["LIMITACIONES"] = $fdata;
//	DOCENTEACARGO
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 12;
	$fdata["strName"] = "DOCENTEACARGO";
	$fdata["GoodName"] = "DOCENTEACARGO";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("estudiantes","DOCENTEACARGO");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

	
		$fdata["bEditPage"] = true;

	
		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "DOCENTEACARGO";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "DOCENTEACARGO";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
	
		
	
// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "docente";
		$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "NOMBRES";
	$edata["LinkFieldType"] = 0;
	$edata["DisplayField"] = "NOMBRES";
	
	

	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataestudiantes["DOCENTEACARGO"] = $fdata;
//	FOTODEPERFIL
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 13;
	$fdata["strName"] = "FOTODEPERFIL";
	$fdata["GoodName"] = "FOTODEPERFIL";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("estudiantes","FOTODEPERFIL");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

	
		$fdata["bEditPage"] = true;

	
		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "FOTODEPERFIL";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "FOTODEPERFIL";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "File-based Image");

	
	
				$vdata["ShowThumbnail"] = true;
	$vdata["ThumbWidth"] = 200;
	$vdata["ThumbHeight"] = 200;
			$vdata["ImageWidth"] = 200;
	$vdata["ImageHeight"] = 200;

	
	
	
	
	
	
	
	
	
	
		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Document upload");

	
	
		
	


	
	
	
							$edata["acceptFileTypes"] = "bmp";
						$edata["acceptFileTypes"] .= "|gif";
						$edata["acceptFileTypes"] .= "|jpg";
						$edata["acceptFileTypes"] .= "|png";
		$edata["acceptFileTypes"] = "(".$edata["acceptFileTypes"].")$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

		$edata["CreateThumbnail"] = true;
	$edata["StrThumbnail"] = "th";
			$edata["ThumbnailSize"] = 600;

				$edata["ResizeImage"] = true;
				$edata["NewSize"] = 600;

	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataestudiantes["FOTODEPERFIL"] = $fdata;


$tables_data["estudiantes"]=&$tdataestudiantes;
$field_labels["estudiantes"] = &$fieldLabelsestudiantes;
$fieldToolTips["estudiantes"] = &$fieldToolTipsestudiantes;
$placeHolders["estudiantes"] = &$placeHoldersestudiantes;
$page_titles["estudiantes"] = &$pageTitlesestudiantes;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["estudiantes"] = array();

// tables which are master tables for current table (detail)
$masterTablesData["estudiantes"] = array();


// -----------------end  prepare master-details data arrays ------------------------------//

require_once(getabspath("classes/sql.php"));










function createSqlQuery_estudiantes()
{
$proto3=array();
$proto3["m_strHead"] = "SELECT";
$proto3["m_strFieldList"] = "ID_ESTUDIANTE,  	NOMBRE,  	FECHANACIMIENTO,  	DIRECCION,  	TELEFONO,  	DIAGNOSTICO,  	NOMBREDELPADRE,  	NOMBREDELAMADRE,  	NOMBREACUDIENTE,  	HABILIDADES,  	LIMITACIONES,  	DOCENTEACARGO,  	FOTODEPERFIL";
$proto3["m_strFrom"] = "FROM estudiantes";
$proto3["m_strWhere"] = "";
$proto3["m_strOrderBy"] = "";
	
		;
			$proto3["cipherer"] = null;
$proto5=array();
$proto5["m_sql"] = "";
$proto5["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto5["m_column"]=$obj;
$proto5["m_contained"] = array();
$proto5["m_strCase"] = "";
$proto5["m_havingmode"] = false;
$proto5["m_inBrackets"] = false;
$proto5["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto5);

$proto3["m_where"] = $obj;
$proto7=array();
$proto7["m_sql"] = "";
$proto7["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto7["m_column"]=$obj;
$proto7["m_contained"] = array();
$proto7["m_strCase"] = "";
$proto7["m_havingmode"] = false;
$proto7["m_inBrackets"] = false;
$proto7["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto7);

$proto3["m_having"] = $obj;
$proto3["m_fieldlist"] = array();
						$proto9=array();
			$obj = new SQLField(array(
	"m_strName" => "ID_ESTUDIANTE",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "estudiantes"
));

$proto9["m_sql"] = "ID_ESTUDIANTE";
$proto9["m_srcTableName"] = "estudiantes";
$proto9["m_expr"]=$obj;
$proto9["m_alias"] = "";
$obj = new SQLFieldListItem($proto9);

$proto3["m_fieldlist"][]=$obj;
						$proto11=array();
			$obj = new SQLField(array(
	"m_strName" => "NOMBRE",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "estudiantes"
));

$proto11["m_sql"] = "NOMBRE";
$proto11["m_srcTableName"] = "estudiantes";
$proto11["m_expr"]=$obj;
$proto11["m_alias"] = "";
$obj = new SQLFieldListItem($proto11);

$proto3["m_fieldlist"][]=$obj;
						$proto13=array();
			$obj = new SQLField(array(
	"m_strName" => "FECHANACIMIENTO",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "estudiantes"
));

$proto13["m_sql"] = "FECHANACIMIENTO";
$proto13["m_srcTableName"] = "estudiantes";
$proto13["m_expr"]=$obj;
$proto13["m_alias"] = "";
$obj = new SQLFieldListItem($proto13);

$proto3["m_fieldlist"][]=$obj;
						$proto15=array();
			$obj = new SQLField(array(
	"m_strName" => "DIRECCION",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "estudiantes"
));

$proto15["m_sql"] = "DIRECCION";
$proto15["m_srcTableName"] = "estudiantes";
$proto15["m_expr"]=$obj;
$proto15["m_alias"] = "";
$obj = new SQLFieldListItem($proto15);

$proto3["m_fieldlist"][]=$obj;
						$proto17=array();
			$obj = new SQLField(array(
	"m_strName" => "TELEFONO",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "estudiantes"
));

$proto17["m_sql"] = "TELEFONO";
$proto17["m_srcTableName"] = "estudiantes";
$proto17["m_expr"]=$obj;
$proto17["m_alias"] = "";
$obj = new SQLFieldListItem($proto17);

$proto3["m_fieldlist"][]=$obj;
						$proto19=array();
			$obj = new SQLField(array(
	"m_strName" => "DIAGNOSTICO",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "estudiantes"
));

$proto19["m_sql"] = "DIAGNOSTICO";
$proto19["m_srcTableName"] = "estudiantes";
$proto19["m_expr"]=$obj;
$proto19["m_alias"] = "";
$obj = new SQLFieldListItem($proto19);

$proto3["m_fieldlist"][]=$obj;
						$proto21=array();
			$obj = new SQLField(array(
	"m_strName" => "NOMBREDELPADRE",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "estudiantes"
));

$proto21["m_sql"] = "NOMBREDELPADRE";
$proto21["m_srcTableName"] = "estudiantes";
$proto21["m_expr"]=$obj;
$proto21["m_alias"] = "";
$obj = new SQLFieldListItem($proto21);

$proto3["m_fieldlist"][]=$obj;
						$proto23=array();
			$obj = new SQLField(array(
	"m_strName" => "NOMBREDELAMADRE",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "estudiantes"
));

$proto23["m_sql"] = "NOMBREDELAMADRE";
$proto23["m_srcTableName"] = "estudiantes";
$proto23["m_expr"]=$obj;
$proto23["m_alias"] = "";
$obj = new SQLFieldListItem($proto23);

$proto3["m_fieldlist"][]=$obj;
						$proto25=array();
			$obj = new SQLField(array(
	"m_strName" => "NOMBREACUDIENTE",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "estudiantes"
));

$proto25["m_sql"] = "NOMBREACUDIENTE";
$proto25["m_srcTableName"] = "estudiantes";
$proto25["m_expr"]=$obj;
$proto25["m_alias"] = "";
$obj = new SQLFieldListItem($proto25);

$proto3["m_fieldlist"][]=$obj;
						$proto27=array();
			$obj = new SQLField(array(
	"m_strName" => "HABILIDADES",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "estudiantes"
));

$proto27["m_sql"] = "HABILIDADES";
$proto27["m_srcTableName"] = "estudiantes";
$proto27["m_expr"]=$obj;
$proto27["m_alias"] = "";
$obj = new SQLFieldListItem($proto27);

$proto3["m_fieldlist"][]=$obj;
						$proto29=array();
			$obj = new SQLField(array(
	"m_strName" => "LIMITACIONES",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "estudiantes"
));

$proto29["m_sql"] = "LIMITACIONES";
$proto29["m_srcTableName"] = "estudiantes";
$proto29["m_expr"]=$obj;
$proto29["m_alias"] = "";
$obj = new SQLFieldListItem($proto29);

$proto3["m_fieldlist"][]=$obj;
						$proto31=array();
			$obj = new SQLField(array(
	"m_strName" => "DOCENTEACARGO",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "estudiantes"
));

$proto31["m_sql"] = "DOCENTEACARGO";
$proto31["m_srcTableName"] = "estudiantes";
$proto31["m_expr"]=$obj;
$proto31["m_alias"] = "";
$obj = new SQLFieldListItem($proto31);

$proto3["m_fieldlist"][]=$obj;
						$proto33=array();
			$obj = new SQLField(array(
	"m_strName" => "FOTODEPERFIL",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "estudiantes"
));

$proto33["m_sql"] = "FOTODEPERFIL";
$proto33["m_srcTableName"] = "estudiantes";
$proto33["m_expr"]=$obj;
$proto33["m_alias"] = "";
$obj = new SQLFieldListItem($proto33);

$proto3["m_fieldlist"][]=$obj;
$proto3["m_fromlist"] = array();
												$proto35=array();
$proto35["m_link"] = "SQLL_MAIN";
			$proto36=array();
$proto36["m_strName"] = "estudiantes";
$proto36["m_srcTableName"] = "estudiantes";
$proto36["m_columns"] = array();
$proto36["m_columns"][] = "ID_ESTUDIANTE";
$proto36["m_columns"][] = "NOMBRE";
$proto36["m_columns"][] = "FECHANACIMIENTO";
$proto36["m_columns"][] = "DIRECCION";
$proto36["m_columns"][] = "TELEFONO";
$proto36["m_columns"][] = "DIAGNOSTICO";
$proto36["m_columns"][] = "NOMBREDELPADRE";
$proto36["m_columns"][] = "NOMBREDELAMADRE";
$proto36["m_columns"][] = "NOMBREACUDIENTE";
$proto36["m_columns"][] = "HABILIDADES";
$proto36["m_columns"][] = "LIMITACIONES";
$proto36["m_columns"][] = "DOCENTEACARGO";
$proto36["m_columns"][] = "FOTODEPERFIL";
$obj = new SQLTable($proto36);

$proto35["m_table"] = $obj;
$proto35["m_sql"] = "estudiantes";
$proto35["m_alias"] = "";
$proto35["m_srcTableName"] = "estudiantes";
$proto37=array();
$proto37["m_sql"] = "";
$proto37["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto37["m_column"]=$obj;
$proto37["m_contained"] = array();
$proto37["m_strCase"] = "";
$proto37["m_havingmode"] = false;
$proto37["m_inBrackets"] = false;
$proto37["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto37);

$proto35["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto35);

$proto3["m_fromlist"][]=$obj;
$proto3["m_groupby"] = array();
$proto3["m_orderby"] = array();
$proto3["m_srcTableName"]="estudiantes";		
$obj = new SQLQuery($proto3);

	return $obj;
}
$queryData_estudiantes = createSqlQuery_estudiantes();


	
		;

													

$tdataestudiantes[".sqlquery"] = $queryData_estudiantes;

$tableEvents["estudiantes"] = new eventsBase;
$tdataestudiantes[".hasEvents"] = false;

?>