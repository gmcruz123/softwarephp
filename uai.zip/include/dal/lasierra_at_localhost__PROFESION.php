<?php
$dalTableprofesion = array();
$dalTableprofesion["ID_PROFESION"] = array("type"=>3,"varname"=>"ID_PROFESION", "name" => "ID_PROFESION");
$dalTableprofesion["PROFESION"] = array("type"=>200,"varname"=>"PROFESION", "name" => "PROFESION");
	$dalTableprofesion["ID_PROFESION"]["key"]=true;

$dal_info["lasierra_at_localhost__profesion"] = &$dalTableprofesion;
?>