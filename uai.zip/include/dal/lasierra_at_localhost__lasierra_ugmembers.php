<?php
$dalTablelasierra_ugmembers = array();
$dalTablelasierra_ugmembers["UserName"] = array("type"=>200,"varname"=>"UserName", "name" => "UserName");
$dalTablelasierra_ugmembers["GroupID"] = array("type"=>3,"varname"=>"GroupID", "name" => "GroupID");
	$dalTablelasierra_ugmembers["UserName"]["key"]=true;
	$dalTablelasierra_ugmembers["GroupID"]["key"]=true;

$dal_info["lasierra_at_localhost__lasierra_ugmembers"] = &$dalTablelasierra_ugmembers;
?>