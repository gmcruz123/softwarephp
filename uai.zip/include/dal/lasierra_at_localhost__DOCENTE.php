<?php
$dalTabledocente = array();
$dalTabledocente["ID_DOCENTE"] = array("type"=>3,"varname"=>"ID_DOCENTE", "name" => "ID_DOCENTE");
$dalTabledocente["NOMBRES"] = array("type"=>200,"varname"=>"NOMBRES", "name" => "NOMBRES");
$dalTabledocente["CELULAR"] = array("type"=>3,"varname"=>"CELULAR", "name" => "CELULAR");
$dalTabledocente["CORREO"] = array("type"=>200,"varname"=>"CORREO", "name" => "CORREO");
$dalTabledocente["ASIGNATURA"] = array("type"=>200,"varname"=>"ASIGNATURA", "name" => "ASIGNATURA");
$dalTabledocente["PROFESION"] = array("type"=>200,"varname"=>"PROFESION", "name" => "PROFESION");
$dalTabledocente["FECHACUMPLEAÑOS"] = array("type"=>135,"varname"=>"FECHACUMPLEA_OS", "name" => "FECHACUMPLEAÑOS");
$dalTabledocente["ESTADO"] = array("type"=>200,"varname"=>"ESTADO", "name" => "ESTADO");
$dalTabledocente["FECHADEREGISTRO"] = array("type"=>135,"varname"=>"FECHADEREGISTRO", "name" => "FECHADEREGISTRO");
$dalTabledocente["CEDULA"] = array("type"=>3,"varname"=>"CEDULA", "name" => "CEDULA");
$dalTabledocente["PASS"] = array("type"=>200,"varname"=>"PASS", "name" => "PASS");
$dalTabledocente["FOTOPERFIL"] = array("type"=>200,"varname"=>"FOTOPERFIL", "name" => "FOTOPERFIL");
	$dalTabledocente["ID_DOCENTE"]["key"]=true;

$dal_info["lasierra_at_localhost__docente"] = &$dalTabledocente;
?>