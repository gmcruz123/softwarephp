<?php
$dalTablelasierra_ugrights = array();
$dalTablelasierra_ugrights["TableName"] = array("type"=>200,"varname"=>"TableName", "name" => "TableName");
$dalTablelasierra_ugrights["GroupID"] = array("type"=>3,"varname"=>"GroupID", "name" => "GroupID");
$dalTablelasierra_ugrights["AccessMask"] = array("type"=>200,"varname"=>"AccessMask", "name" => "AccessMask");
	$dalTablelasierra_ugrights["TableName"]["key"]=true;
	$dalTablelasierra_ugrights["GroupID"]["key"]=true;

$dal_info["lasierra_at_localhost__lasierra_ugrights"] = &$dalTablelasierra_ugrights;
?>