<?php
$dalTablelasierra_uggroups = array();
$dalTablelasierra_uggroups["GroupID"] = array("type"=>3,"varname"=>"GroupID", "name" => "GroupID");
$dalTablelasierra_uggroups["Label"] = array("type"=>200,"varname"=>"Label", "name" => "Label");
	$dalTablelasierra_uggroups["GroupID"]["key"]=true;

$dal_info["lasierra_at_localhost__lasierra_uggroups"] = &$dalTablelasierra_uggroups;
?>