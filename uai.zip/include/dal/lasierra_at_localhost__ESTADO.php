<?php
$dalTableestado = array();
$dalTableestado["FID_ESTADO"] = array("type"=>3,"varname"=>"FID_ESTADO", "name" => "FID_ESTADO");
$dalTableestado["DESCRIPCION"] = array("type"=>200,"varname"=>"DESCRIPCION", "name" => "DESCRIPCION");
	$dalTableestado["FID_ESTADO"]["key"]=true;

$dal_info["lasierra_at_localhost__estado"] = &$dalTableestado;
?>