<?php
$dalTableestudiantes = array();
$dalTableestudiantes["ID_ESTUDIANTE"] = array("type"=>3,"varname"=>"ID_ESTUDIANTE", "name" => "ID_ESTUDIANTE");
$dalTableestudiantes["NOMBRE"] = array("type"=>200,"varname"=>"NOMBRE", "name" => "NOMBRE");
$dalTableestudiantes["FECHANACIMIENTO"] = array("type"=>135,"varname"=>"FECHANACIMIENTO", "name" => "FECHANACIMIENTO");
$dalTableestudiantes["DIRECCION"] = array("type"=>200,"varname"=>"DIRECCION", "name" => "DIRECCION");
$dalTableestudiantes["TELEFONO"] = array("type"=>3,"varname"=>"TELEFONO", "name" => "TELEFONO");
$dalTableestudiantes["DIAGNOSTICO"] = array("type"=>200,"varname"=>"DIAGNOSTICO", "name" => "DIAGNOSTICO");
$dalTableestudiantes["NOMBREDELPADRE"] = array("type"=>200,"varname"=>"NOMBREDELPADRE", "name" => "NOMBREDELPADRE");
$dalTableestudiantes["NOMBREDELAMADRE"] = array("type"=>200,"varname"=>"NOMBREDELAMADRE", "name" => "NOMBREDELAMADRE");
$dalTableestudiantes["NOMBREACUDIENTE"] = array("type"=>200,"varname"=>"NOMBREACUDIENTE", "name" => "NOMBREACUDIENTE");
$dalTableestudiantes["HABILIDADES"] = array("type"=>200,"varname"=>"HABILIDADES", "name" => "HABILIDADES");
$dalTableestudiantes["LIMITACIONES"] = array("type"=>200,"varname"=>"LIMITACIONES", "name" => "LIMITACIONES");
$dalTableestudiantes["DOCENTEACARGO"] = array("type"=>200,"varname"=>"DOCENTEACARGO", "name" => "DOCENTEACARGO");
$dalTableestudiantes["FOTODEPERFIL"] = array("type"=>200,"varname"=>"FOTODEPERFIL", "name" => "FOTODEPERFIL");
	$dalTableestudiantes["ID_ESTUDIANTE"]["key"]=true;

$dal_info["lasierra_at_localhost__estudiantes"] = &$dalTableestudiantes;
?>