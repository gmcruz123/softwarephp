<?php
$dalTableasignatura = array();
$dalTableasignatura["ID_ASIGNATURA"] = array("type"=>3,"varname"=>"ID_ASIGNATURA", "name" => "ID_ASIGNATURA");
$dalTableasignatura["DESCRIPCION"] = array("type"=>200,"varname"=>"DESCRIPCION", "name" => "DESCRIPCION");
	$dalTableasignatura["ID_ASIGNATURA"]["key"]=true;

$dal_info["lasierra_at_localhost__asignatura"] = &$dalTableasignatura;
?>