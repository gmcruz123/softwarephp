<?php
$dalTableroles = array();
$dalTableroles["ID_ROLES"] = array("type"=>3,"varname"=>"ID_ROLES", "name" => "ID_ROLES");
$dalTableroles["ROLES"] = array("type"=>200,"varname"=>"ROLES", "name" => "ROLES");
	$dalTableroles["ID_ROLES"]["key"]=true;

$dal_info["lasierra_at_localhost__roles"] = &$dalTableroles;
?>