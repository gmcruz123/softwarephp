<?php
$strTableName="Quienes Somos";


// alias for 'SQLQuery' object
$gSettings = new ProjectSettings("Quienes Somos");
$eventObj = &$tableEvents["Quienes Somos"];

?>