<?php
require_once(getabspath("classes/cipherer.php"));




$tdataESTUDIANTESACARGO = array();
	$tdataESTUDIANTESACARGO[".truncateText"] = true;
	$tdataESTUDIANTESACARGO[".NumberOfChars"] = 80;
	$tdataESTUDIANTESACARGO[".ShortName"] = "ESTUDIANTESACARGO";
	$tdataESTUDIANTESACARGO[".OwnerID"] = "";
	$tdataESTUDIANTESACARGO[".OriginalTable"] = "estudiantes";

//	field labels
$fieldLabelsESTUDIANTESACARGO = array();
$fieldToolTipsESTUDIANTESACARGO = array();
$pageTitlesESTUDIANTESACARGO = array();
$placeHoldersESTUDIANTESACARGO = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsESTUDIANTESACARGO["English"] = array();
	$fieldToolTipsESTUDIANTESACARGO["English"] = array();
	$placeHoldersESTUDIANTESACARGO["English"] = array();
	$pageTitlesESTUDIANTESACARGO["English"] = array();
	$fieldLabelsESTUDIANTESACARGO["English"]["ID_ESTUDIANTE"] = "ID ESTUDIANTE";
	$fieldToolTipsESTUDIANTESACARGO["English"]["ID_ESTUDIANTE"] = "";
	$placeHoldersESTUDIANTESACARGO["English"]["ID_ESTUDIANTE"] = "";
	$fieldLabelsESTUDIANTESACARGO["English"]["NOMBRE"] = "NOMBRE";
	$fieldToolTipsESTUDIANTESACARGO["English"]["NOMBRE"] = "";
	$placeHoldersESTUDIANTESACARGO["English"]["NOMBRE"] = "";
	$fieldLabelsESTUDIANTESACARGO["English"]["FECHANACIMIENTO"] = "FECHANACIMIENTO";
	$fieldToolTipsESTUDIANTESACARGO["English"]["FECHANACIMIENTO"] = "";
	$placeHoldersESTUDIANTESACARGO["English"]["FECHANACIMIENTO"] = "";
	$fieldLabelsESTUDIANTESACARGO["English"]["DIRECCION"] = "DIRECCION";
	$fieldToolTipsESTUDIANTESACARGO["English"]["DIRECCION"] = "";
	$placeHoldersESTUDIANTESACARGO["English"]["DIRECCION"] = "";
	$fieldLabelsESTUDIANTESACARGO["English"]["TELEFONO"] = "TELEFONO";
	$fieldToolTipsESTUDIANTESACARGO["English"]["TELEFONO"] = "";
	$placeHoldersESTUDIANTESACARGO["English"]["TELEFONO"] = "";
	$fieldLabelsESTUDIANTESACARGO["English"]["DIAGNOSTICO"] = "DIAGNOSTICO";
	$fieldToolTipsESTUDIANTESACARGO["English"]["DIAGNOSTICO"] = "";
	$placeHoldersESTUDIANTESACARGO["English"]["DIAGNOSTICO"] = "";
	$fieldLabelsESTUDIANTESACARGO["English"]["NOMBREDELPADRE"] = "NOMBREDELPADRE";
	$fieldToolTipsESTUDIANTESACARGO["English"]["NOMBREDELPADRE"] = "";
	$placeHoldersESTUDIANTESACARGO["English"]["NOMBREDELPADRE"] = "";
	$fieldLabelsESTUDIANTESACARGO["English"]["NOMBREDELAMADRE"] = "NOMBREDELAMADRE";
	$fieldToolTipsESTUDIANTESACARGO["English"]["NOMBREDELAMADRE"] = "";
	$placeHoldersESTUDIANTESACARGO["English"]["NOMBREDELAMADRE"] = "";
	$fieldLabelsESTUDIANTESACARGO["English"]["NOMBREACUDIENTE"] = "NOMBREACUDIENTE";
	$fieldToolTipsESTUDIANTESACARGO["English"]["NOMBREACUDIENTE"] = "";
	$placeHoldersESTUDIANTESACARGO["English"]["NOMBREACUDIENTE"] = "";
	$fieldLabelsESTUDIANTESACARGO["English"]["HABILIDADES"] = "HABILIDADES";
	$fieldToolTipsESTUDIANTESACARGO["English"]["HABILIDADES"] = "";
	$placeHoldersESTUDIANTESACARGO["English"]["HABILIDADES"] = "";
	$fieldLabelsESTUDIANTESACARGO["English"]["LIMITACIONES"] = "LIMITACIONES";
	$fieldToolTipsESTUDIANTESACARGO["English"]["LIMITACIONES"] = "";
	$placeHoldersESTUDIANTESACARGO["English"]["LIMITACIONES"] = "";
	$fieldLabelsESTUDIANTESACARGO["English"]["DOCENTEACARGO"] = "DOCENTEACARGO";
	$fieldToolTipsESTUDIANTESACARGO["English"]["DOCENTEACARGO"] = "";
	$placeHoldersESTUDIANTESACARGO["English"]["DOCENTEACARGO"] = "";
	$fieldLabelsESTUDIANTESACARGO["English"]["FOTODEPERFIL"] = "FOTODEPERFIL";
	$fieldToolTipsESTUDIANTESACARGO["English"]["FOTODEPERFIL"] = "";
	$placeHoldersESTUDIANTESACARGO["English"]["FOTODEPERFIL"] = "";
	if (count($fieldToolTipsESTUDIANTESACARGO["English"]))
		$tdataESTUDIANTESACARGO[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="")
{
	$fieldLabelsESTUDIANTESACARGO[""] = array();
	$fieldToolTipsESTUDIANTESACARGO[""] = array();
	$placeHoldersESTUDIANTESACARGO[""] = array();
	$pageTitlesESTUDIANTESACARGO[""] = array();
	$fieldLabelsESTUDIANTESACARGO[""]["ID_ESTUDIANTE"] = "ID ESTUDIANTE";
	$fieldToolTipsESTUDIANTESACARGO[""]["ID_ESTUDIANTE"] = "";
	$placeHoldersESTUDIANTESACARGO[""]["ID_ESTUDIANTE"] = "";
	$fieldLabelsESTUDIANTESACARGO[""]["NOMBRE"] = "NOMBRE";
	$fieldToolTipsESTUDIANTESACARGO[""]["NOMBRE"] = "";
	$placeHoldersESTUDIANTESACARGO[""]["NOMBRE"] = "";
	$fieldLabelsESTUDIANTESACARGO[""]["FECHANACIMIENTO"] = "FECHANACIMIENTO";
	$fieldToolTipsESTUDIANTESACARGO[""]["FECHANACIMIENTO"] = "";
	$placeHoldersESTUDIANTESACARGO[""]["FECHANACIMIENTO"] = "";
	$fieldLabelsESTUDIANTESACARGO[""]["DIRECCION"] = "DIRECCION";
	$fieldToolTipsESTUDIANTESACARGO[""]["DIRECCION"] = "";
	$placeHoldersESTUDIANTESACARGO[""]["DIRECCION"] = "";
	$fieldLabelsESTUDIANTESACARGO[""]["TELEFONO"] = "TELEFONO";
	$fieldToolTipsESTUDIANTESACARGO[""]["TELEFONO"] = "";
	$placeHoldersESTUDIANTESACARGO[""]["TELEFONO"] = "";
	$fieldLabelsESTUDIANTESACARGO[""]["DIAGNOSTICO"] = "DIAGNOSTICO";
	$fieldToolTipsESTUDIANTESACARGO[""]["DIAGNOSTICO"] = "";
	$placeHoldersESTUDIANTESACARGO[""]["DIAGNOSTICO"] = "";
	$fieldLabelsESTUDIANTESACARGO[""]["NOMBREDELPADRE"] = "NOMBREDELPADRE";
	$fieldToolTipsESTUDIANTESACARGO[""]["NOMBREDELPADRE"] = "";
	$placeHoldersESTUDIANTESACARGO[""]["NOMBREDELPADRE"] = "";
	$fieldLabelsESTUDIANTESACARGO[""]["NOMBREDELAMADRE"] = "NOMBREDELAMADRE";
	$fieldToolTipsESTUDIANTESACARGO[""]["NOMBREDELAMADRE"] = "";
	$placeHoldersESTUDIANTESACARGO[""]["NOMBREDELAMADRE"] = "";
	$fieldLabelsESTUDIANTESACARGO[""]["NOMBREACUDIENTE"] = "NOMBREACUDIENTE";
	$fieldToolTipsESTUDIANTESACARGO[""]["NOMBREACUDIENTE"] = "";
	$placeHoldersESTUDIANTESACARGO[""]["NOMBREACUDIENTE"] = "";
	$fieldLabelsESTUDIANTESACARGO[""]["HABILIDADES"] = "HABILIDADES";
	$fieldToolTipsESTUDIANTESACARGO[""]["HABILIDADES"] = "";
	$placeHoldersESTUDIANTESACARGO[""]["HABILIDADES"] = "";
	$fieldLabelsESTUDIANTESACARGO[""]["LIMITACIONES"] = "LIMITACIONES";
	$fieldToolTipsESTUDIANTESACARGO[""]["LIMITACIONES"] = "";
	$placeHoldersESTUDIANTESACARGO[""]["LIMITACIONES"] = "";
	$fieldLabelsESTUDIANTESACARGO[""]["DOCENTEACARGO"] = "DOCENTEACARGO";
	$fieldToolTipsESTUDIANTESACARGO[""]["DOCENTEACARGO"] = "";
	$placeHoldersESTUDIANTESACARGO[""]["DOCENTEACARGO"] = "";
	$fieldLabelsESTUDIANTESACARGO[""]["FOTODEPERFIL"] = "FOTODEPERFIL";
	$fieldToolTipsESTUDIANTESACARGO[""]["FOTODEPERFIL"] = "";
	$placeHoldersESTUDIANTESACARGO[""]["FOTODEPERFIL"] = "";
	if (count($fieldToolTipsESTUDIANTESACARGO[""]))
		$tdataESTUDIANTESACARGO[".isUseToolTips"] = true;
}


	$tdataESTUDIANTESACARGO[".NCSearch"] = true;



$tdataESTUDIANTESACARGO[".shortTableName"] = "ESTUDIANTESACARGO";
$tdataESTUDIANTESACARGO[".nSecOptions"] = 0;
$tdataESTUDIANTESACARGO[".recsPerRowPrint"] = 1;
$tdataESTUDIANTESACARGO[".mainTableOwnerID"] = "";
$tdataESTUDIANTESACARGO[".moveNext"] = 1;
$tdataESTUDIANTESACARGO[".entityType"] = 1;

$tdataESTUDIANTESACARGO[".strOriginalTableName"] = "estudiantes";

	



$tdataESTUDIANTESACARGO[".showAddInPopup"] = true;

$tdataESTUDIANTESACARGO[".showEditInPopup"] = true;

$tdataESTUDIANTESACARGO[".showViewInPopup"] = true;

//page's base css files names
$popupPagesLayoutNames = array();
			;
$popupPagesLayoutNames["add"] = "login_bootstrap";
			;
$popupPagesLayoutNames["edit"] = "login_bootstrap";
						
	;
$popupPagesLayoutNames["view"] = "view_bootstrap_2col";
$tdataESTUDIANTESACARGO[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdataESTUDIANTESACARGO[".fieldsForRegister"] = array();

$tdataESTUDIANTESACARGO[".listAjax"] = false;

	$tdataESTUDIANTESACARGO[".audit"] = false;

	$tdataESTUDIANTESACARGO[".locking"] = false;



$tdataESTUDIANTESACARGO[".list"] = true;



$tdataESTUDIANTESACARGO[".reorderRecordsByHeader"] = true;



$tdataESTUDIANTESACARGO[".view"] = true;





$tdataESTUDIANTESACARGO[".showSimpleSearchOptions"] = false;

// Allow Show/Hide Fields in GRID
$tdataESTUDIANTESACARGO[".allowShowHideFields"] = false;
//

// Allow Fields Reordering in GRID
$tdataESTUDIANTESACARGO[".allowFieldsReordering"] = false;
//

// search Saving settings
$tdataESTUDIANTESACARGO[".searchSaving"] = false;
//

$tdataESTUDIANTESACARGO[".showSearchPanel"] = true;
		$tdataESTUDIANTESACARGO[".flexibleSearch"] = true;

$tdataESTUDIANTESACARGO[".isUseAjaxSuggest"] = true;

$tdataESTUDIANTESACARGO[".rowHighlite"] = true;





$tdataESTUDIANTESACARGO[".ajaxCodeSnippetAdded"] = false;

$tdataESTUDIANTESACARGO[".buttonsAdded"] = false;

$tdataESTUDIANTESACARGO[".addPageEvents"] = false;

// use timepicker for search panel
$tdataESTUDIANTESACARGO[".isUseTimeForSearch"] = false;



$tdataESTUDIANTESACARGO[".badgeColor"] = "CD5C5C";


$tdataESTUDIANTESACARGO[".allSearchFields"] = array();
$tdataESTUDIANTESACARGO[".filterFields"] = array();
$tdataESTUDIANTESACARGO[".requiredSearchFields"] = array();

$tdataESTUDIANTESACARGO[".allSearchFields"][] = "ID_ESTUDIANTE";
	$tdataESTUDIANTESACARGO[".allSearchFields"][] = "NOMBRE";
	$tdataESTUDIANTESACARGO[".allSearchFields"][] = "FECHANACIMIENTO";
	$tdataESTUDIANTESACARGO[".allSearchFields"][] = "DIRECCION";
	$tdataESTUDIANTESACARGO[".allSearchFields"][] = "TELEFONO";
	$tdataESTUDIANTESACARGO[".allSearchFields"][] = "DIAGNOSTICO";
	$tdataESTUDIANTESACARGO[".allSearchFields"][] = "NOMBREDELPADRE";
	$tdataESTUDIANTESACARGO[".allSearchFields"][] = "NOMBREDELAMADRE";
	$tdataESTUDIANTESACARGO[".allSearchFields"][] = "NOMBREACUDIENTE";
	$tdataESTUDIANTESACARGO[".allSearchFields"][] = "HABILIDADES";
	$tdataESTUDIANTESACARGO[".allSearchFields"][] = "LIMITACIONES";
	$tdataESTUDIANTESACARGO[".allSearchFields"][] = "DOCENTEACARGO";
	$tdataESTUDIANTESACARGO[".allSearchFields"][] = "FOTODEPERFIL";
	

$tdataESTUDIANTESACARGO[".googleLikeFields"] = array();
$tdataESTUDIANTESACARGO[".googleLikeFields"][] = "ID_ESTUDIANTE";
$tdataESTUDIANTESACARGO[".googleLikeFields"][] = "NOMBRE";
$tdataESTUDIANTESACARGO[".googleLikeFields"][] = "FECHANACIMIENTO";
$tdataESTUDIANTESACARGO[".googleLikeFields"][] = "DIRECCION";
$tdataESTUDIANTESACARGO[".googleLikeFields"][] = "TELEFONO";
$tdataESTUDIANTESACARGO[".googleLikeFields"][] = "DIAGNOSTICO";
$tdataESTUDIANTESACARGO[".googleLikeFields"][] = "NOMBREDELPADRE";
$tdataESTUDIANTESACARGO[".googleLikeFields"][] = "NOMBREDELAMADRE";
$tdataESTUDIANTESACARGO[".googleLikeFields"][] = "NOMBREACUDIENTE";
$tdataESTUDIANTESACARGO[".googleLikeFields"][] = "HABILIDADES";
$tdataESTUDIANTESACARGO[".googleLikeFields"][] = "LIMITACIONES";
$tdataESTUDIANTESACARGO[".googleLikeFields"][] = "DOCENTEACARGO";
$tdataESTUDIANTESACARGO[".googleLikeFields"][] = "FOTODEPERFIL";


$tdataESTUDIANTESACARGO[".advSearchFields"] = array();
$tdataESTUDIANTESACARGO[".advSearchFields"][] = "ID_ESTUDIANTE";
$tdataESTUDIANTESACARGO[".advSearchFields"][] = "NOMBRE";
$tdataESTUDIANTESACARGO[".advSearchFields"][] = "FECHANACIMIENTO";
$tdataESTUDIANTESACARGO[".advSearchFields"][] = "DIRECCION";
$tdataESTUDIANTESACARGO[".advSearchFields"][] = "TELEFONO";
$tdataESTUDIANTESACARGO[".advSearchFields"][] = "DIAGNOSTICO";
$tdataESTUDIANTESACARGO[".advSearchFields"][] = "NOMBREDELPADRE";
$tdataESTUDIANTESACARGO[".advSearchFields"][] = "NOMBREDELAMADRE";
$tdataESTUDIANTESACARGO[".advSearchFields"][] = "NOMBREACUDIENTE";
$tdataESTUDIANTESACARGO[".advSearchFields"][] = "HABILIDADES";
$tdataESTUDIANTESACARGO[".advSearchFields"][] = "LIMITACIONES";
$tdataESTUDIANTESACARGO[".advSearchFields"][] = "DOCENTEACARGO";
$tdataESTUDIANTESACARGO[".advSearchFields"][] = "FOTODEPERFIL";

$tdataESTUDIANTESACARGO[".tableType"] = "list";

$tdataESTUDIANTESACARGO[".printerPageOrientation"] = 0;
$tdataESTUDIANTESACARGO[".nPrinterPageScale"] = 100;

$tdataESTUDIANTESACARGO[".nPrinterSplitRecords"] = 40;

$tdataESTUDIANTESACARGO[".nPrinterPDFSplitRecords"] = 40;



$tdataESTUDIANTESACARGO[".geocodingEnabled"] = false;





$tdataESTUDIANTESACARGO[".listGridLayout"] = 3;





// view page pdf

// print page pdf


$tdataESTUDIANTESACARGO[".pageSize"] = 20;

$tdataESTUDIANTESACARGO[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdataESTUDIANTESACARGO[".strOrderBy"] = $tstrOrderBy;

$tdataESTUDIANTESACARGO[".orderindexes"] = array();

$tdataESTUDIANTESACARGO[".sqlHead"] = "SELECT ID_ESTUDIANTE,  	NOMBRE,  	FECHANACIMIENTO,  	DIRECCION,  	TELEFONO,  	DIAGNOSTICO,  	NOMBREDELPADRE,  	NOMBREDELAMADRE,  	NOMBREACUDIENTE,  	HABILIDADES,  	LIMITACIONES,  	DOCENTEACARGO,  	FOTODEPERFIL";
$tdataESTUDIANTESACARGO[".sqlFrom"] = "FROM estudiantes";
$tdataESTUDIANTESACARGO[".sqlWhereExpr"] = "";
$tdataESTUDIANTESACARGO[".sqlTail"] = "";












//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataESTUDIANTESACARGO[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataESTUDIANTESACARGO[".arrGroupsPerPage"] = $arrGPP;

$tdataESTUDIANTESACARGO[".highlightSearchResults"] = true;

$tableKeysESTUDIANTESACARGO = array();
$tableKeysESTUDIANTESACARGO[] = "ID_ESTUDIANTE";
$tdataESTUDIANTESACARGO[".Keys"] = $tableKeysESTUDIANTESACARGO;

$tdataESTUDIANTESACARGO[".listFields"] = array();
$tdataESTUDIANTESACARGO[".listFields"][] = "FOTODEPERFIL";
$tdataESTUDIANTESACARGO[".listFields"][] = "NOMBRE";
$tdataESTUDIANTESACARGO[".listFields"][] = "DIAGNOSTICO";
$tdataESTUDIANTESACARGO[".listFields"][] = "LIMITACIONES";
$tdataESTUDIANTESACARGO[".listFields"][] = "DOCENTEACARGO";
$tdataESTUDIANTESACARGO[".listFields"][] = "FECHANACIMIENTO";

$tdataESTUDIANTESACARGO[".hideMobileList"] = array();


$tdataESTUDIANTESACARGO[".viewFields"] = array();
$tdataESTUDIANTESACARGO[".viewFields"][] = "NOMBRE";
$tdataESTUDIANTESACARGO[".viewFields"][] = "FECHANACIMIENTO";
$tdataESTUDIANTESACARGO[".viewFields"][] = "DIRECCION";
$tdataESTUDIANTESACARGO[".viewFields"][] = "TELEFONO";
$tdataESTUDIANTESACARGO[".viewFields"][] = "DIAGNOSTICO";
$tdataESTUDIANTESACARGO[".viewFields"][] = "NOMBREDELPADRE";
$tdataESTUDIANTESACARGO[".viewFields"][] = "NOMBREDELAMADRE";
$tdataESTUDIANTESACARGO[".viewFields"][] = "NOMBREACUDIENTE";
$tdataESTUDIANTESACARGO[".viewFields"][] = "HABILIDADES";
$tdataESTUDIANTESACARGO[".viewFields"][] = "LIMITACIONES";
$tdataESTUDIANTESACARGO[".viewFields"][] = "DOCENTEACARGO";
$tdataESTUDIANTESACARGO[".viewFields"][] = "FOTODEPERFIL";

$tdataESTUDIANTESACARGO[".addFields"] = array();

$tdataESTUDIANTESACARGO[".masterListFields"] = array();
$tdataESTUDIANTESACARGO[".masterListFields"][] = "ID_ESTUDIANTE";
$tdataESTUDIANTESACARGO[".masterListFields"][] = "NOMBRE";
$tdataESTUDIANTESACARGO[".masterListFields"][] = "FECHANACIMIENTO";
$tdataESTUDIANTESACARGO[".masterListFields"][] = "DIRECCION";
$tdataESTUDIANTESACARGO[".masterListFields"][] = "TELEFONO";
$tdataESTUDIANTESACARGO[".masterListFields"][] = "DIAGNOSTICO";
$tdataESTUDIANTESACARGO[".masterListFields"][] = "NOMBREDELPADRE";
$tdataESTUDIANTESACARGO[".masterListFields"][] = "NOMBREDELAMADRE";
$tdataESTUDIANTESACARGO[".masterListFields"][] = "NOMBREACUDIENTE";
$tdataESTUDIANTESACARGO[".masterListFields"][] = "HABILIDADES";
$tdataESTUDIANTESACARGO[".masterListFields"][] = "LIMITACIONES";
$tdataESTUDIANTESACARGO[".masterListFields"][] = "DOCENTEACARGO";
$tdataESTUDIANTESACARGO[".masterListFields"][] = "FOTODEPERFIL";

$tdataESTUDIANTESACARGO[".inlineAddFields"] = array();

$tdataESTUDIANTESACARGO[".editFields"] = array();

$tdataESTUDIANTESACARGO[".inlineEditFields"] = array();

$tdataESTUDIANTESACARGO[".updateSelectedFields"] = array();


$tdataESTUDIANTESACARGO[".exportFields"] = array();

$tdataESTUDIANTESACARGO[".importFields"] = array();

$tdataESTUDIANTESACARGO[".printFields"] = array();


//	ID_ESTUDIANTE
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "ID_ESTUDIANTE";
	$fdata["GoodName"] = "ID_ESTUDIANTE";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("ESTUDIANTESACARGO","ID_ESTUDIANTE");
	$fdata["FieldType"] = 3;

	
		$fdata["AutoInc"] = true;

	
			
	
	
	
	
	
	

	
		$fdata["bAdvancedSearch"] = true;

	
	
		$fdata["strField"] = "ID_ESTUDIANTE";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "ID_ESTUDIANTE";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


		$edata["IsRequired"] = true;

	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataESTUDIANTESACARGO["ID_ESTUDIANTE"] = $fdata;
//	NOMBRE
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "NOMBRE";
	$fdata["GoodName"] = "NOMBRE";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("ESTUDIANTESACARGO","NOMBRE");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

	
	
	
	
	

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

	
	
		$fdata["strField"] = "NOMBRE";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "NOMBRE";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataESTUDIANTESACARGO["NOMBRE"] = $fdata;
//	FECHANACIMIENTO
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "FECHANACIMIENTO";
	$fdata["GoodName"] = "FECHANACIMIENTO";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("ESTUDIANTESACARGO","FECHANACIMIENTO");
	$fdata["FieldType"] = 135;

	
	
	
			
		$fdata["bListPage"] = true;

	
	
	
	
	

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

	
	
		$fdata["strField"] = "FECHANACIMIENTO";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "FECHANACIMIENTO";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Short Date");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Date");

	
	
		
	


		$edata["IsRequired"] = true;

	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
		$edata["DateEditType"] = 2;
	$edata["InitialYearFactor"] = 1;
	$edata["LastYearFactor"] = 1;

	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between", EMPTY_SEARCH, NOT_EMPTY );
// the end of search options settings




	$tdataESTUDIANTESACARGO["FECHANACIMIENTO"] = $fdata;
//	DIRECCION
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "DIRECCION";
	$fdata["GoodName"] = "DIRECCION";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("ESTUDIANTESACARGO","DIRECCION");
	$fdata["FieldType"] = 200;

	
	
	
			
	
	
	
	
	
	

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

	
	
		$fdata["strField"] = "DIRECCION";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "DIRECCION";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataESTUDIANTESACARGO["DIRECCION"] = $fdata;
//	TELEFONO
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "TELEFONO";
	$fdata["GoodName"] = "TELEFONO";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("ESTUDIANTESACARGO","TELEFONO");
	$fdata["FieldType"] = 3;

	
	
	
			
	
	
	
	
	
	

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

	
	
		$fdata["strField"] = "TELEFONO";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "TELEFONO";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


		$edata["IsRequired"] = true;

	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "number";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataESTUDIANTESACARGO["TELEFONO"] = $fdata;
//	DIAGNOSTICO
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "DIAGNOSTICO";
	$fdata["GoodName"] = "DIAGNOSTICO";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("ESTUDIANTESACARGO","DIAGNOSTICO");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

	
	
	
	
	

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

	
	
		$fdata["strField"] = "DIAGNOSTICO";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "DIAGNOSTICO";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text area");

	
	
		
	


		$edata["IsRequired"] = true;

	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
				$edata["nRows"] = 100;
			$edata["nCols"] = 200;

	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataESTUDIANTESACARGO["DIAGNOSTICO"] = $fdata;
//	NOMBREDELPADRE
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "NOMBREDELPADRE";
	$fdata["GoodName"] = "NOMBREDELPADRE";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("ESTUDIANTESACARGO","NOMBREDELPADRE");
	$fdata["FieldType"] = 200;

	
	
	
			
	
	
	
	
	
	

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

	
	
		$fdata["strField"] = "NOMBREDELPADRE";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "NOMBREDELPADRE";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataESTUDIANTESACARGO["NOMBREDELPADRE"] = $fdata;
//	NOMBREDELAMADRE
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 8;
	$fdata["strName"] = "NOMBREDELAMADRE";
	$fdata["GoodName"] = "NOMBREDELAMADRE";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("ESTUDIANTESACARGO","NOMBREDELAMADRE");
	$fdata["FieldType"] = 200;

	
	
	
			
	
	
	
	
	
	

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

	
	
		$fdata["strField"] = "NOMBREDELAMADRE";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "NOMBREDELAMADRE";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataESTUDIANTESACARGO["NOMBREDELAMADRE"] = $fdata;
//	NOMBREACUDIENTE
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 9;
	$fdata["strName"] = "NOMBREACUDIENTE";
	$fdata["GoodName"] = "NOMBREACUDIENTE";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("ESTUDIANTESACARGO","NOMBREACUDIENTE");
	$fdata["FieldType"] = 200;

	
	
	
			
	
	
	
	
	
	

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

	
	
		$fdata["strField"] = "NOMBREACUDIENTE";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "NOMBREACUDIENTE";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataESTUDIANTESACARGO["NOMBREACUDIENTE"] = $fdata;
//	HABILIDADES
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 10;
	$fdata["strName"] = "HABILIDADES";
	$fdata["GoodName"] = "HABILIDADES";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("ESTUDIANTESACARGO","HABILIDADES");
	$fdata["FieldType"] = 200;

	
	
	
			
	
	
	
	
	
	

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

	
	
		$fdata["strField"] = "HABILIDADES";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "HABILIDADES";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text area");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
				$edata["nRows"] = 100;
			$edata["nCols"] = 200;

	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataESTUDIANTESACARGO["HABILIDADES"] = $fdata;
//	LIMITACIONES
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 11;
	$fdata["strName"] = "LIMITACIONES";
	$fdata["GoodName"] = "LIMITACIONES";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("ESTUDIANTESACARGO","LIMITACIONES");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

	
	
	
	
	

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

	
	
		$fdata["strField"] = "LIMITACIONES";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "LIMITACIONES";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text area");

	
	
		
	


		$edata["IsRequired"] = true;

	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
				$edata["nRows"] = 100;
			$edata["nCols"] = 200;

	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataESTUDIANTESACARGO["LIMITACIONES"] = $fdata;
//	DOCENTEACARGO
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 12;
	$fdata["strName"] = "DOCENTEACARGO";
	$fdata["GoodName"] = "DOCENTEACARGO";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("ESTUDIANTESACARGO","DOCENTEACARGO");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

	
	
	
	
	

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

	
	
		$fdata["strField"] = "DOCENTEACARGO";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "DOCENTEACARGO";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
	
		
	
// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "docente";
		$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "NOMBRES";
	$edata["LinkFieldType"] = 0;
	$edata["DisplayField"] = "NOMBRES";
	
	

	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataESTUDIANTESACARGO["DOCENTEACARGO"] = $fdata;
//	FOTODEPERFIL
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 13;
	$fdata["strName"] = "FOTODEPERFIL";
	$fdata["GoodName"] = "FOTODEPERFIL";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("ESTUDIANTESACARGO","FOTODEPERFIL");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

	
	
	
	
	

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

	
	
		$fdata["strField"] = "FOTODEPERFIL";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "FOTODEPERFIL";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=300";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataESTUDIANTESACARGO["FOTODEPERFIL"] = $fdata;


$tables_data["ESTUDIANTESACARGO"]=&$tdataESTUDIANTESACARGO;
$field_labels["ESTUDIANTESACARGO"] = &$fieldLabelsESTUDIANTESACARGO;
$fieldToolTips["ESTUDIANTESACARGO"] = &$fieldToolTipsESTUDIANTESACARGO;
$placeHolders["ESTUDIANTESACARGO"] = &$placeHoldersESTUDIANTESACARGO;
$page_titles["ESTUDIANTESACARGO"] = &$pageTitlesESTUDIANTESACARGO;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["ESTUDIANTESACARGO"] = array();

// tables which are master tables for current table (detail)
$masterTablesData["ESTUDIANTESACARGO"] = array();


// -----------------end  prepare master-details data arrays ------------------------------//

require_once(getabspath("classes/sql.php"));










function createSqlQuery_ESTUDIANTESACARGO()
{
$proto3=array();
$proto3["m_strHead"] = "SELECT";
$proto3["m_strFieldList"] = "ID_ESTUDIANTE,  	NOMBRE,  	FECHANACIMIENTO,  	DIRECCION,  	TELEFONO,  	DIAGNOSTICO,  	NOMBREDELPADRE,  	NOMBREDELAMADRE,  	NOMBREACUDIENTE,  	HABILIDADES,  	LIMITACIONES,  	DOCENTEACARGO,  	FOTODEPERFIL";
$proto3["m_strFrom"] = "FROM estudiantes";
$proto3["m_strWhere"] = "";
$proto3["m_strOrderBy"] = "";
	
		;
			$proto3["cipherer"] = null;
$proto5=array();
$proto5["m_sql"] = "";
$proto5["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto5["m_column"]=$obj;
$proto5["m_contained"] = array();
$proto5["m_strCase"] = "";
$proto5["m_havingmode"] = false;
$proto5["m_inBrackets"] = false;
$proto5["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto5);

$proto3["m_where"] = $obj;
$proto7=array();
$proto7["m_sql"] = "";
$proto7["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto7["m_column"]=$obj;
$proto7["m_contained"] = array();
$proto7["m_strCase"] = "";
$proto7["m_havingmode"] = false;
$proto7["m_inBrackets"] = false;
$proto7["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto7);

$proto3["m_having"] = $obj;
$proto3["m_fieldlist"] = array();
						$proto9=array();
			$obj = new SQLField(array(
	"m_strName" => "ID_ESTUDIANTE",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "ESTUDIANTESACARGO"
));

$proto9["m_sql"] = "ID_ESTUDIANTE";
$proto9["m_srcTableName"] = "ESTUDIANTESACARGO";
$proto9["m_expr"]=$obj;
$proto9["m_alias"] = "";
$obj = new SQLFieldListItem($proto9);

$proto3["m_fieldlist"][]=$obj;
						$proto11=array();
			$obj = new SQLField(array(
	"m_strName" => "NOMBRE",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "ESTUDIANTESACARGO"
));

$proto11["m_sql"] = "NOMBRE";
$proto11["m_srcTableName"] = "ESTUDIANTESACARGO";
$proto11["m_expr"]=$obj;
$proto11["m_alias"] = "";
$obj = new SQLFieldListItem($proto11);

$proto3["m_fieldlist"][]=$obj;
						$proto13=array();
			$obj = new SQLField(array(
	"m_strName" => "FECHANACIMIENTO",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "ESTUDIANTESACARGO"
));

$proto13["m_sql"] = "FECHANACIMIENTO";
$proto13["m_srcTableName"] = "ESTUDIANTESACARGO";
$proto13["m_expr"]=$obj;
$proto13["m_alias"] = "";
$obj = new SQLFieldListItem($proto13);

$proto3["m_fieldlist"][]=$obj;
						$proto15=array();
			$obj = new SQLField(array(
	"m_strName" => "DIRECCION",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "ESTUDIANTESACARGO"
));

$proto15["m_sql"] = "DIRECCION";
$proto15["m_srcTableName"] = "ESTUDIANTESACARGO";
$proto15["m_expr"]=$obj;
$proto15["m_alias"] = "";
$obj = new SQLFieldListItem($proto15);

$proto3["m_fieldlist"][]=$obj;
						$proto17=array();
			$obj = new SQLField(array(
	"m_strName" => "TELEFONO",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "ESTUDIANTESACARGO"
));

$proto17["m_sql"] = "TELEFONO";
$proto17["m_srcTableName"] = "ESTUDIANTESACARGO";
$proto17["m_expr"]=$obj;
$proto17["m_alias"] = "";
$obj = new SQLFieldListItem($proto17);

$proto3["m_fieldlist"][]=$obj;
						$proto19=array();
			$obj = new SQLField(array(
	"m_strName" => "DIAGNOSTICO",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "ESTUDIANTESACARGO"
));

$proto19["m_sql"] = "DIAGNOSTICO";
$proto19["m_srcTableName"] = "ESTUDIANTESACARGO";
$proto19["m_expr"]=$obj;
$proto19["m_alias"] = "";
$obj = new SQLFieldListItem($proto19);

$proto3["m_fieldlist"][]=$obj;
						$proto21=array();
			$obj = new SQLField(array(
	"m_strName" => "NOMBREDELPADRE",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "ESTUDIANTESACARGO"
));

$proto21["m_sql"] = "NOMBREDELPADRE";
$proto21["m_srcTableName"] = "ESTUDIANTESACARGO";
$proto21["m_expr"]=$obj;
$proto21["m_alias"] = "";
$obj = new SQLFieldListItem($proto21);

$proto3["m_fieldlist"][]=$obj;
						$proto23=array();
			$obj = new SQLField(array(
	"m_strName" => "NOMBREDELAMADRE",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "ESTUDIANTESACARGO"
));

$proto23["m_sql"] = "NOMBREDELAMADRE";
$proto23["m_srcTableName"] = "ESTUDIANTESACARGO";
$proto23["m_expr"]=$obj;
$proto23["m_alias"] = "";
$obj = new SQLFieldListItem($proto23);

$proto3["m_fieldlist"][]=$obj;
						$proto25=array();
			$obj = new SQLField(array(
	"m_strName" => "NOMBREACUDIENTE",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "ESTUDIANTESACARGO"
));

$proto25["m_sql"] = "NOMBREACUDIENTE";
$proto25["m_srcTableName"] = "ESTUDIANTESACARGO";
$proto25["m_expr"]=$obj;
$proto25["m_alias"] = "";
$obj = new SQLFieldListItem($proto25);

$proto3["m_fieldlist"][]=$obj;
						$proto27=array();
			$obj = new SQLField(array(
	"m_strName" => "HABILIDADES",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "ESTUDIANTESACARGO"
));

$proto27["m_sql"] = "HABILIDADES";
$proto27["m_srcTableName"] = "ESTUDIANTESACARGO";
$proto27["m_expr"]=$obj;
$proto27["m_alias"] = "";
$obj = new SQLFieldListItem($proto27);

$proto3["m_fieldlist"][]=$obj;
						$proto29=array();
			$obj = new SQLField(array(
	"m_strName" => "LIMITACIONES",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "ESTUDIANTESACARGO"
));

$proto29["m_sql"] = "LIMITACIONES";
$proto29["m_srcTableName"] = "ESTUDIANTESACARGO";
$proto29["m_expr"]=$obj;
$proto29["m_alias"] = "";
$obj = new SQLFieldListItem($proto29);

$proto3["m_fieldlist"][]=$obj;
						$proto31=array();
			$obj = new SQLField(array(
	"m_strName" => "DOCENTEACARGO",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "ESTUDIANTESACARGO"
));

$proto31["m_sql"] = "DOCENTEACARGO";
$proto31["m_srcTableName"] = "ESTUDIANTESACARGO";
$proto31["m_expr"]=$obj;
$proto31["m_alias"] = "";
$obj = new SQLFieldListItem($proto31);

$proto3["m_fieldlist"][]=$obj;
						$proto33=array();
			$obj = new SQLField(array(
	"m_strName" => "FOTODEPERFIL",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "ESTUDIANTESACARGO"
));

$proto33["m_sql"] = "FOTODEPERFIL";
$proto33["m_srcTableName"] = "ESTUDIANTESACARGO";
$proto33["m_expr"]=$obj;
$proto33["m_alias"] = "";
$obj = new SQLFieldListItem($proto33);

$proto3["m_fieldlist"][]=$obj;
$proto3["m_fromlist"] = array();
												$proto35=array();
$proto35["m_link"] = "SQLL_MAIN";
			$proto36=array();
$proto36["m_strName"] = "estudiantes";
$proto36["m_srcTableName"] = "ESTUDIANTESACARGO";
$proto36["m_columns"] = array();
$proto36["m_columns"][] = "ID_ESTUDIANTE";
$proto36["m_columns"][] = "NOMBRE";
$proto36["m_columns"][] = "FECHANACIMIENTO";
$proto36["m_columns"][] = "DIRECCION";
$proto36["m_columns"][] = "TELEFONO";
$proto36["m_columns"][] = "DIAGNOSTICO";
$proto36["m_columns"][] = "NOMBREDELPADRE";
$proto36["m_columns"][] = "NOMBREDELAMADRE";
$proto36["m_columns"][] = "NOMBREACUDIENTE";
$proto36["m_columns"][] = "HABILIDADES";
$proto36["m_columns"][] = "LIMITACIONES";
$proto36["m_columns"][] = "DOCENTEACARGO";
$proto36["m_columns"][] = "FOTODEPERFIL";
$obj = new SQLTable($proto36);

$proto35["m_table"] = $obj;
$proto35["m_sql"] = "estudiantes";
$proto35["m_alias"] = "";
$proto35["m_srcTableName"] = "ESTUDIANTESACARGO";
$proto37=array();
$proto37["m_sql"] = "";
$proto37["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto37["m_column"]=$obj;
$proto37["m_contained"] = array();
$proto37["m_strCase"] = "";
$proto37["m_havingmode"] = false;
$proto37["m_inBrackets"] = false;
$proto37["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto37);

$proto35["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto35);

$proto3["m_fromlist"][]=$obj;
$proto3["m_groupby"] = array();
$proto3["m_orderby"] = array();
$proto3["m_srcTableName"]="ESTUDIANTESACARGO";		
$obj = new SQLQuery($proto3);

	return $obj;
}
$queryData_ESTUDIANTESACARGO = createSqlQuery_ESTUDIANTESACARGO();


	
		;

													

$tdataESTUDIANTESACARGO[".sqlquery"] = $queryData_ESTUDIANTESACARGO;

$tableEvents["ESTUDIANTESACARGO"] = new eventsBase;
$tdataESTUDIANTESACARGO[".hasEvents"] = false;

?>