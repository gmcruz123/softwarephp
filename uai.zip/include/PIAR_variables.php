<?php
$strTableName="PIAR";


// alias for 'SQLQuery' object
$gSettings = new ProjectSettings("PIAR");
$eventObj = &$tableEvents["PIAR"];

?>