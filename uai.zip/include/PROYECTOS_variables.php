<?php
$strTableName="PROYECTOS";


// alias for 'SQLQuery' object
$gSettings = new ProjectSettings("PROYECTOS");
$eventObj = &$tableEvents["PROYECTOS"];

?>