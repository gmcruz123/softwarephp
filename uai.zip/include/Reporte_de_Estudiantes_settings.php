<?php
require_once(getabspath("classes/cipherer.php"));




$tdataReporte_de_Estudiantes = array();
	$tdataReporte_de_Estudiantes[".truncateText"] = true;
	$tdataReporte_de_Estudiantes[".NumberOfChars"] = 80;
	$tdataReporte_de_Estudiantes[".ShortName"] = "Reporte_de_Estudiantes";
	$tdataReporte_de_Estudiantes[".OwnerID"] = "";
	$tdataReporte_de_Estudiantes[".OriginalTable"] = "estudiantes";

//	field labels
$fieldLabelsReporte_de_Estudiantes = array();
$fieldToolTipsReporte_de_Estudiantes = array();
$pageTitlesReporte_de_Estudiantes = array();
$placeHoldersReporte_de_Estudiantes = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsReporte_de_Estudiantes["English"] = array();
	$fieldToolTipsReporte_de_Estudiantes["English"] = array();
	$placeHoldersReporte_de_Estudiantes["English"] = array();
	$pageTitlesReporte_de_Estudiantes["English"] = array();
	$fieldLabelsReporte_de_Estudiantes["English"]["ID_ESTUDIANTE"] = "ID ESTUDIANTE";
	$fieldToolTipsReporte_de_Estudiantes["English"]["ID_ESTUDIANTE"] = "";
	$placeHoldersReporte_de_Estudiantes["English"]["ID_ESTUDIANTE"] = "";
	$fieldLabelsReporte_de_Estudiantes["English"]["NOMBRE"] = "NOMBRE";
	$fieldToolTipsReporte_de_Estudiantes["English"]["NOMBRE"] = "";
	$placeHoldersReporte_de_Estudiantes["English"]["NOMBRE"] = "";
	$fieldLabelsReporte_de_Estudiantes["English"]["FECHANACIMIENTO"] = "FECHANACIMIENTO";
	$fieldToolTipsReporte_de_Estudiantes["English"]["FECHANACIMIENTO"] = "";
	$placeHoldersReporte_de_Estudiantes["English"]["FECHANACIMIENTO"] = "";
	$fieldLabelsReporte_de_Estudiantes["English"]["DIRECCION"] = "DIRECCION";
	$fieldToolTipsReporte_de_Estudiantes["English"]["DIRECCION"] = "";
	$placeHoldersReporte_de_Estudiantes["English"]["DIRECCION"] = "";
	$fieldLabelsReporte_de_Estudiantes["English"]["TELEFONO"] = "TELEFONO";
	$fieldToolTipsReporte_de_Estudiantes["English"]["TELEFONO"] = "";
	$placeHoldersReporte_de_Estudiantes["English"]["TELEFONO"] = "";
	$fieldLabelsReporte_de_Estudiantes["English"]["DIAGNOSTICO"] = "DIAGNOSTICO";
	$fieldToolTipsReporte_de_Estudiantes["English"]["DIAGNOSTICO"] = "";
	$placeHoldersReporte_de_Estudiantes["English"]["DIAGNOSTICO"] = "";
	$fieldLabelsReporte_de_Estudiantes["English"]["NOMBREDELPADRE"] = "NOMBREDELPADRE";
	$fieldToolTipsReporte_de_Estudiantes["English"]["NOMBREDELPADRE"] = "";
	$placeHoldersReporte_de_Estudiantes["English"]["NOMBREDELPADRE"] = "";
	$fieldLabelsReporte_de_Estudiantes["English"]["NOMBREDELAMADRE"] = "NOMBREDELAMADRE";
	$fieldToolTipsReporte_de_Estudiantes["English"]["NOMBREDELAMADRE"] = "";
	$placeHoldersReporte_de_Estudiantes["English"]["NOMBREDELAMADRE"] = "";
	$fieldLabelsReporte_de_Estudiantes["English"]["NOMBREACUDIENTE"] = "NOMBREACUDIENTE";
	$fieldToolTipsReporte_de_Estudiantes["English"]["NOMBREACUDIENTE"] = "";
	$placeHoldersReporte_de_Estudiantes["English"]["NOMBREACUDIENTE"] = "";
	$fieldLabelsReporte_de_Estudiantes["English"]["HABILIDADES"] = "HABILIDADES";
	$fieldToolTipsReporte_de_Estudiantes["English"]["HABILIDADES"] = "";
	$placeHoldersReporte_de_Estudiantes["English"]["HABILIDADES"] = "";
	$fieldLabelsReporte_de_Estudiantes["English"]["LIMITACIONES"] = "LIMITACIONES";
	$fieldToolTipsReporte_de_Estudiantes["English"]["LIMITACIONES"] = "";
	$placeHoldersReporte_de_Estudiantes["English"]["LIMITACIONES"] = "";
	$fieldLabelsReporte_de_Estudiantes["English"]["DOCENTEACARGO"] = "DOCENTEACARGO";
	$fieldToolTipsReporte_de_Estudiantes["English"]["DOCENTEACARGO"] = "";
	$placeHoldersReporte_de_Estudiantes["English"]["DOCENTEACARGO"] = "";
	$fieldLabelsReporte_de_Estudiantes["English"]["FOTODEPERFIL"] = "FOTODEPERFIL";
	$fieldToolTipsReporte_de_Estudiantes["English"]["FOTODEPERFIL"] = "";
	$placeHoldersReporte_de_Estudiantes["English"]["FOTODEPERFIL"] = "";
	if (count($fieldToolTipsReporte_de_Estudiantes["English"]))
		$tdataReporte_de_Estudiantes[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="")
{
	$fieldLabelsReporte_de_Estudiantes[""] = array();
	$fieldToolTipsReporte_de_Estudiantes[""] = array();
	$placeHoldersReporte_de_Estudiantes[""] = array();
	$pageTitlesReporte_de_Estudiantes[""] = array();
	$fieldLabelsReporte_de_Estudiantes[""]["ID_ESTUDIANTE"] = "ID ESTUDIANTE";
	$fieldToolTipsReporte_de_Estudiantes[""]["ID_ESTUDIANTE"] = "";
	$placeHoldersReporte_de_Estudiantes[""]["ID_ESTUDIANTE"] = "";
	$fieldLabelsReporte_de_Estudiantes[""]["NOMBRE"] = "NOMBRE";
	$fieldToolTipsReporte_de_Estudiantes[""]["NOMBRE"] = "";
	$placeHoldersReporte_de_Estudiantes[""]["NOMBRE"] = "";
	$fieldLabelsReporte_de_Estudiantes[""]["FECHANACIMIENTO"] = "FECHANACIMIENTO";
	$fieldToolTipsReporte_de_Estudiantes[""]["FECHANACIMIENTO"] = "";
	$placeHoldersReporte_de_Estudiantes[""]["FECHANACIMIENTO"] = "";
	$fieldLabelsReporte_de_Estudiantes[""]["DIRECCION"] = "DIRECCION";
	$fieldToolTipsReporte_de_Estudiantes[""]["DIRECCION"] = "";
	$placeHoldersReporte_de_Estudiantes[""]["DIRECCION"] = "";
	$fieldLabelsReporte_de_Estudiantes[""]["TELEFONO"] = "TELEFONO";
	$fieldToolTipsReporte_de_Estudiantes[""]["TELEFONO"] = "";
	$placeHoldersReporte_de_Estudiantes[""]["TELEFONO"] = "";
	$fieldLabelsReporte_de_Estudiantes[""]["DIAGNOSTICO"] = "DIAGNOSTICO";
	$fieldToolTipsReporte_de_Estudiantes[""]["DIAGNOSTICO"] = "";
	$placeHoldersReporte_de_Estudiantes[""]["DIAGNOSTICO"] = "";
	$fieldLabelsReporte_de_Estudiantes[""]["NOMBREDELPADRE"] = "NOMBREDELPADRE";
	$fieldToolTipsReporte_de_Estudiantes[""]["NOMBREDELPADRE"] = "";
	$placeHoldersReporte_de_Estudiantes[""]["NOMBREDELPADRE"] = "";
	$fieldLabelsReporte_de_Estudiantes[""]["NOMBREDELAMADRE"] = "NOMBREDELAMADRE";
	$fieldToolTipsReporte_de_Estudiantes[""]["NOMBREDELAMADRE"] = "";
	$placeHoldersReporte_de_Estudiantes[""]["NOMBREDELAMADRE"] = "";
	$fieldLabelsReporte_de_Estudiantes[""]["NOMBREACUDIENTE"] = "NOMBREACUDIENTE";
	$fieldToolTipsReporte_de_Estudiantes[""]["NOMBREACUDIENTE"] = "";
	$placeHoldersReporte_de_Estudiantes[""]["NOMBREACUDIENTE"] = "";
	$fieldLabelsReporte_de_Estudiantes[""]["HABILIDADES"] = "HABILIDADES";
	$fieldToolTipsReporte_de_Estudiantes[""]["HABILIDADES"] = "";
	$placeHoldersReporte_de_Estudiantes[""]["HABILIDADES"] = "";
	$fieldLabelsReporte_de_Estudiantes[""]["LIMITACIONES"] = "LIMITACIONES";
	$fieldToolTipsReporte_de_Estudiantes[""]["LIMITACIONES"] = "";
	$placeHoldersReporte_de_Estudiantes[""]["LIMITACIONES"] = "";
	$fieldLabelsReporte_de_Estudiantes[""]["DOCENTEACARGO"] = "DOCENTEACARGO";
	$fieldToolTipsReporte_de_Estudiantes[""]["DOCENTEACARGO"] = "";
	$placeHoldersReporte_de_Estudiantes[""]["DOCENTEACARGO"] = "";
	$fieldLabelsReporte_de_Estudiantes[""]["FOTODEPERFIL"] = "FOTODEPERFIL";
	$fieldToolTipsReporte_de_Estudiantes[""]["FOTODEPERFIL"] = "";
	$placeHoldersReporte_de_Estudiantes[""]["FOTODEPERFIL"] = "";
	if (count($fieldToolTipsReporte_de_Estudiantes[""]))
		$tdataReporte_de_Estudiantes[".isUseToolTips"] = true;
}


	$tdataReporte_de_Estudiantes[".NCSearch"] = true;



$tdataReporte_de_Estudiantes[".shortTableName"] = "Reporte_de_Estudiantes";
$tdataReporte_de_Estudiantes[".nSecOptions"] = 0;
$tdataReporte_de_Estudiantes[".recsPerRowPrint"] = 1;
$tdataReporte_de_Estudiantes[".mainTableOwnerID"] = "";
$tdataReporte_de_Estudiantes[".moveNext"] = 1;
$tdataReporte_de_Estudiantes[".entityType"] = 2;

$tdataReporte_de_Estudiantes[".strOriginalTableName"] = "estudiantes";

	



$tdataReporte_de_Estudiantes[".showAddInPopup"] = false;

$tdataReporte_de_Estudiantes[".showEditInPopup"] = false;

$tdataReporte_de_Estudiantes[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdataReporte_de_Estudiantes[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdataReporte_de_Estudiantes[".fieldsForRegister"] = array();

$tdataReporte_de_Estudiantes[".listAjax"] = false;

	$tdataReporte_de_Estudiantes[".audit"] = false;

	$tdataReporte_de_Estudiantes[".locking"] = false;

$tdataReporte_de_Estudiantes[".edit"] = true;
$tdataReporte_de_Estudiantes[".afterEditAction"] = 1;
$tdataReporte_de_Estudiantes[".closePopupAfterEdit"] = 1;
$tdataReporte_de_Estudiantes[".afterEditActionDetTable"] = "";

$tdataReporte_de_Estudiantes[".add"] = true;
$tdataReporte_de_Estudiantes[".afterAddAction"] = 1;
$tdataReporte_de_Estudiantes[".closePopupAfterAdd"] = 1;
$tdataReporte_de_Estudiantes[".afterAddActionDetTable"] = "";

$tdataReporte_de_Estudiantes[".list"] = true;



$tdataReporte_de_Estudiantes[".reorderRecordsByHeader"] = true;


$tdataReporte_de_Estudiantes[".exportFormatting"] = 2;
$tdataReporte_de_Estudiantes[".exportDelimiter"] = ",";
		
$tdataReporte_de_Estudiantes[".view"] = true;


$tdataReporte_de_Estudiantes[".exportTo"] = true;

$tdataReporte_de_Estudiantes[".printFriendly"] = true;

$tdataReporte_de_Estudiantes[".delete"] = true;

$tdataReporte_de_Estudiantes[".showSimpleSearchOptions"] = false;

// Allow Show/Hide Fields in GRID
$tdataReporte_de_Estudiantes[".allowShowHideFields"] = false;
//

// Allow Fields Reordering in GRID
$tdataReporte_de_Estudiantes[".allowFieldsReordering"] = false;
//

// search Saving settings
$tdataReporte_de_Estudiantes[".searchSaving"] = false;
//

$tdataReporte_de_Estudiantes[".showSearchPanel"] = true;
		$tdataReporte_de_Estudiantes[".flexibleSearch"] = true;

$tdataReporte_de_Estudiantes[".isUseAjaxSuggest"] = true;






$tdataReporte_de_Estudiantes[".ajaxCodeSnippetAdded"] = false;

$tdataReporte_de_Estudiantes[".buttonsAdded"] = false;

$tdataReporte_de_Estudiantes[".addPageEvents"] = false;

// use timepicker for search panel
$tdataReporte_de_Estudiantes[".isUseTimeForSearch"] = false;





$tdataReporte_de_Estudiantes[".allSearchFields"] = array();
$tdataReporte_de_Estudiantes[".filterFields"] = array();
$tdataReporte_de_Estudiantes[".requiredSearchFields"] = array();

$tdataReporte_de_Estudiantes[".allSearchFields"][] = "ID_ESTUDIANTE";
	$tdataReporte_de_Estudiantes[".allSearchFields"][] = "NOMBRE";
	$tdataReporte_de_Estudiantes[".allSearchFields"][] = "FECHANACIMIENTO";
	$tdataReporte_de_Estudiantes[".allSearchFields"][] = "DIRECCION";
	$tdataReporte_de_Estudiantes[".allSearchFields"][] = "TELEFONO";
	$tdataReporte_de_Estudiantes[".allSearchFields"][] = "DIAGNOSTICO";
	$tdataReporte_de_Estudiantes[".allSearchFields"][] = "NOMBREDELPADRE";
	$tdataReporte_de_Estudiantes[".allSearchFields"][] = "NOMBREDELAMADRE";
	$tdataReporte_de_Estudiantes[".allSearchFields"][] = "NOMBREACUDIENTE";
	$tdataReporte_de_Estudiantes[".allSearchFields"][] = "HABILIDADES";
	$tdataReporte_de_Estudiantes[".allSearchFields"][] = "LIMITACIONES";
	$tdataReporte_de_Estudiantes[".allSearchFields"][] = "DOCENTEACARGO";
	$tdataReporte_de_Estudiantes[".allSearchFields"][] = "FOTODEPERFIL";
	

$tdataReporte_de_Estudiantes[".googleLikeFields"] = array();
$tdataReporte_de_Estudiantes[".googleLikeFields"][] = "ID_ESTUDIANTE";
$tdataReporte_de_Estudiantes[".googleLikeFields"][] = "NOMBRE";
$tdataReporte_de_Estudiantes[".googleLikeFields"][] = "FECHANACIMIENTO";
$tdataReporte_de_Estudiantes[".googleLikeFields"][] = "DIRECCION";
$tdataReporte_de_Estudiantes[".googleLikeFields"][] = "TELEFONO";
$tdataReporte_de_Estudiantes[".googleLikeFields"][] = "DIAGNOSTICO";
$tdataReporte_de_Estudiantes[".googleLikeFields"][] = "NOMBREDELPADRE";
$tdataReporte_de_Estudiantes[".googleLikeFields"][] = "NOMBREDELAMADRE";
$tdataReporte_de_Estudiantes[".googleLikeFields"][] = "NOMBREACUDIENTE";
$tdataReporte_de_Estudiantes[".googleLikeFields"][] = "HABILIDADES";
$tdataReporte_de_Estudiantes[".googleLikeFields"][] = "LIMITACIONES";
$tdataReporte_de_Estudiantes[".googleLikeFields"][] = "DOCENTEACARGO";
$tdataReporte_de_Estudiantes[".googleLikeFields"][] = "FOTODEPERFIL";


$tdataReporte_de_Estudiantes[".advSearchFields"] = array();
$tdataReporte_de_Estudiantes[".advSearchFields"][] = "ID_ESTUDIANTE";
$tdataReporte_de_Estudiantes[".advSearchFields"][] = "NOMBRE";
$tdataReporte_de_Estudiantes[".advSearchFields"][] = "FECHANACIMIENTO";
$tdataReporte_de_Estudiantes[".advSearchFields"][] = "DIRECCION";
$tdataReporte_de_Estudiantes[".advSearchFields"][] = "TELEFONO";
$tdataReporte_de_Estudiantes[".advSearchFields"][] = "DIAGNOSTICO";
$tdataReporte_de_Estudiantes[".advSearchFields"][] = "NOMBREDELPADRE";
$tdataReporte_de_Estudiantes[".advSearchFields"][] = "NOMBREDELAMADRE";
$tdataReporte_de_Estudiantes[".advSearchFields"][] = "NOMBREACUDIENTE";
$tdataReporte_de_Estudiantes[".advSearchFields"][] = "HABILIDADES";
$tdataReporte_de_Estudiantes[".advSearchFields"][] = "LIMITACIONES";
$tdataReporte_de_Estudiantes[".advSearchFields"][] = "DOCENTEACARGO";
$tdataReporte_de_Estudiantes[".advSearchFields"][] = "FOTODEPERFIL";

$tdataReporte_de_Estudiantes[".tableType"] = "report";

$tdataReporte_de_Estudiantes[".printerPageOrientation"] = 1;
$tdataReporte_de_Estudiantes[".nPrinterPageScale"] = 100;

$tdataReporte_de_Estudiantes[".nPrinterSplitRecords"] = 40;

$tdataReporte_de_Estudiantes[".nPrinterPDFSplitRecords"] = 40;



$tdataReporte_de_Estudiantes[".geocodingEnabled"] = false;

//report settings
$tdataReporte_de_Estudiantes[".printReportLayout"] = 1;

$tdataReporte_de_Estudiantes[".reportPrintPartitionType"] = 1;
$tdataReporte_de_Estudiantes[".reportPrintGroupsPerPage"] = 3;
$tdataReporte_de_Estudiantes[".reportPrintPDFGroupsPerPage"] = 3;
$tdataReporte_de_Estudiantes[".lowGroup"] = 4;



$tdataReporte_de_Estudiantes[".reportGroupFields"] = true;
$tdataReporte_de_Estudiantes[".pageSize"] = 5;
$tdataReporte_de_Estudiantes[".showGroupSummaryCount"] = true;
$reportGroupFields = array();
	$rgroupField = array();
	$rgroupField['strGroupField'] = "DIAGNOSTICO";
	$rgroupField['groupInterval'] = 0;
	$rgroupField['groupOrder'] = 1;
	$rgroupField['showGroupSummary'] = "1";
	$rgroupField['crossTabAxis'] = "0";
	$reportGroupFields[] = $rgroupField;
	$rgroupField = array();
	$rgroupField['strGroupField'] = "HABILIDADES";
	$rgroupField['groupInterval'] = 0;
	$rgroupField['groupOrder'] = 2;
	$rgroupField['showGroupSummary'] = "1";
	$rgroupField['crossTabAxis'] = "0";
	$reportGroupFields[] = $rgroupField;
	$rgroupField = array();
	$rgroupField['strGroupField'] = "FECHANACIMIENTO";
	$rgroupField['groupInterval'] = 0;
	$rgroupField['groupOrder'] = 3;
	$rgroupField['showGroupSummary'] = "1";
	$rgroupField['crossTabAxis'] = "0";
	$reportGroupFields[] = $rgroupField;
	$rgroupField = array();
	$rgroupField['strGroupField'] = "LIMITACIONES";
	$rgroupField['groupInterval'] = 0;
	$rgroupField['groupOrder'] = 4;
	$rgroupField['showGroupSummary'] = "1";
	$rgroupField['crossTabAxis'] = "0";
	$reportGroupFields[] = $rgroupField;
$tdataReporte_de_Estudiantes[".reportGroupFieldsData"] = $reportGroupFields;


$tdataReporte_de_Estudiantes[".isExistTotalFields"] = true;




$tdataReporte_de_Estudiantes[".repShowDet"] = true;

$tdataReporte_de_Estudiantes[".reportLayout"] = 1;

//end of report settings




$tdataReporte_de_Estudiantes[".listGridLayout"] = 3;





// view page pdf

// print page pdf



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdataReporte_de_Estudiantes[".strOrderBy"] = $tstrOrderBy;

$tdataReporte_de_Estudiantes[".orderindexes"] = array();

$tdataReporte_de_Estudiantes[".sqlHead"] = "SELECT ID_ESTUDIANTE,  	NOMBRE,  	FECHANACIMIENTO,  	DIRECCION,  	TELEFONO,  	DIAGNOSTICO,  	NOMBREDELPADRE,  	NOMBREDELAMADRE,  	NOMBREACUDIENTE,  	HABILIDADES,  	LIMITACIONES,  	DOCENTEACARGO,  	FOTODEPERFIL";
$tdataReporte_de_Estudiantes[".sqlFrom"] = "FROM estudiantes";
$tdataReporte_de_Estudiantes[".sqlWhereExpr"] = "";
$tdataReporte_de_Estudiantes[".sqlTail"] = "";












//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataReporte_de_Estudiantes[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataReporte_de_Estudiantes[".arrGroupsPerPage"] = $arrGPP;

$tdataReporte_de_Estudiantes[".highlightSearchResults"] = true;

$tableKeysReporte_de_Estudiantes = array();
$tableKeysReporte_de_Estudiantes[] = "ID_ESTUDIANTE";
$tdataReporte_de_Estudiantes[".Keys"] = $tableKeysReporte_de_Estudiantes;

$tdataReporte_de_Estudiantes[".listFields"] = array();
$tdataReporte_de_Estudiantes[".listFields"][] = "ID_ESTUDIANTE";
$tdataReporte_de_Estudiantes[".listFields"][] = "NOMBRE";
$tdataReporte_de_Estudiantes[".listFields"][] = "FECHANACIMIENTO";
$tdataReporte_de_Estudiantes[".listFields"][] = "DIRECCION";
$tdataReporte_de_Estudiantes[".listFields"][] = "TELEFONO";
$tdataReporte_de_Estudiantes[".listFields"][] = "DIAGNOSTICO";
$tdataReporte_de_Estudiantes[".listFields"][] = "NOMBREDELPADRE";
$tdataReporte_de_Estudiantes[".listFields"][] = "NOMBREDELAMADRE";
$tdataReporte_de_Estudiantes[".listFields"][] = "NOMBREACUDIENTE";
$tdataReporte_de_Estudiantes[".listFields"][] = "HABILIDADES";
$tdataReporte_de_Estudiantes[".listFields"][] = "LIMITACIONES";
$tdataReporte_de_Estudiantes[".listFields"][] = "DOCENTEACARGO";
$tdataReporte_de_Estudiantes[".listFields"][] = "FOTODEPERFIL";

$tdataReporte_de_Estudiantes[".hideMobileList"] = array();


$tdataReporte_de_Estudiantes[".viewFields"] = array();
$tdataReporte_de_Estudiantes[".viewFields"][] = "ID_ESTUDIANTE";
$tdataReporte_de_Estudiantes[".viewFields"][] = "NOMBRE";
$tdataReporte_de_Estudiantes[".viewFields"][] = "FECHANACIMIENTO";
$tdataReporte_de_Estudiantes[".viewFields"][] = "DIRECCION";
$tdataReporte_de_Estudiantes[".viewFields"][] = "TELEFONO";
$tdataReporte_de_Estudiantes[".viewFields"][] = "DIAGNOSTICO";
$tdataReporte_de_Estudiantes[".viewFields"][] = "NOMBREDELPADRE";
$tdataReporte_de_Estudiantes[".viewFields"][] = "NOMBREDELAMADRE";
$tdataReporte_de_Estudiantes[".viewFields"][] = "NOMBREACUDIENTE";
$tdataReporte_de_Estudiantes[".viewFields"][] = "HABILIDADES";
$tdataReporte_de_Estudiantes[".viewFields"][] = "LIMITACIONES";
$tdataReporte_de_Estudiantes[".viewFields"][] = "DOCENTEACARGO";
$tdataReporte_de_Estudiantes[".viewFields"][] = "FOTODEPERFIL";

$tdataReporte_de_Estudiantes[".addFields"] = array();
$tdataReporte_de_Estudiantes[".addFields"][] = "NOMBRE";
$tdataReporte_de_Estudiantes[".addFields"][] = "FECHANACIMIENTO";
$tdataReporte_de_Estudiantes[".addFields"][] = "DIRECCION";
$tdataReporte_de_Estudiantes[".addFields"][] = "TELEFONO";
$tdataReporte_de_Estudiantes[".addFields"][] = "DIAGNOSTICO";
$tdataReporte_de_Estudiantes[".addFields"][] = "NOMBREDELPADRE";
$tdataReporte_de_Estudiantes[".addFields"][] = "NOMBREDELAMADRE";
$tdataReporte_de_Estudiantes[".addFields"][] = "NOMBREACUDIENTE";
$tdataReporte_de_Estudiantes[".addFields"][] = "HABILIDADES";
$tdataReporte_de_Estudiantes[".addFields"][] = "LIMITACIONES";
$tdataReporte_de_Estudiantes[".addFields"][] = "DOCENTEACARGO";
$tdataReporte_de_Estudiantes[".addFields"][] = "FOTODEPERFIL";

$tdataReporte_de_Estudiantes[".masterListFields"] = array();
$tdataReporte_de_Estudiantes[".masterListFields"][] = "ID_ESTUDIANTE";
$tdataReporte_de_Estudiantes[".masterListFields"][] = "NOMBRE";
$tdataReporte_de_Estudiantes[".masterListFields"][] = "FECHANACIMIENTO";
$tdataReporte_de_Estudiantes[".masterListFields"][] = "DIRECCION";
$tdataReporte_de_Estudiantes[".masterListFields"][] = "TELEFONO";
$tdataReporte_de_Estudiantes[".masterListFields"][] = "DIAGNOSTICO";
$tdataReporte_de_Estudiantes[".masterListFields"][] = "NOMBREDELPADRE";
$tdataReporte_de_Estudiantes[".masterListFields"][] = "NOMBREDELAMADRE";
$tdataReporte_de_Estudiantes[".masterListFields"][] = "NOMBREACUDIENTE";
$tdataReporte_de_Estudiantes[".masterListFields"][] = "HABILIDADES";
$tdataReporte_de_Estudiantes[".masterListFields"][] = "LIMITACIONES";
$tdataReporte_de_Estudiantes[".masterListFields"][] = "DOCENTEACARGO";
$tdataReporte_de_Estudiantes[".masterListFields"][] = "FOTODEPERFIL";

$tdataReporte_de_Estudiantes[".inlineAddFields"] = array();
$tdataReporte_de_Estudiantes[".inlineAddFields"][] = "NOMBRE";
$tdataReporte_de_Estudiantes[".inlineAddFields"][] = "FECHANACIMIENTO";
$tdataReporte_de_Estudiantes[".inlineAddFields"][] = "DIRECCION";
$tdataReporte_de_Estudiantes[".inlineAddFields"][] = "TELEFONO";
$tdataReporte_de_Estudiantes[".inlineAddFields"][] = "DIAGNOSTICO";
$tdataReporte_de_Estudiantes[".inlineAddFields"][] = "NOMBREDELPADRE";
$tdataReporte_de_Estudiantes[".inlineAddFields"][] = "NOMBREDELAMADRE";
$tdataReporte_de_Estudiantes[".inlineAddFields"][] = "NOMBREACUDIENTE";
$tdataReporte_de_Estudiantes[".inlineAddFields"][] = "HABILIDADES";
$tdataReporte_de_Estudiantes[".inlineAddFields"][] = "LIMITACIONES";
$tdataReporte_de_Estudiantes[".inlineAddFields"][] = "DOCENTEACARGO";
$tdataReporte_de_Estudiantes[".inlineAddFields"][] = "FOTODEPERFIL";

$tdataReporte_de_Estudiantes[".editFields"] = array();
$tdataReporte_de_Estudiantes[".editFields"][] = "NOMBRE";
$tdataReporte_de_Estudiantes[".editFields"][] = "FECHANACIMIENTO";
$tdataReporte_de_Estudiantes[".editFields"][] = "DIRECCION";
$tdataReporte_de_Estudiantes[".editFields"][] = "TELEFONO";
$tdataReporte_de_Estudiantes[".editFields"][] = "DIAGNOSTICO";
$tdataReporte_de_Estudiantes[".editFields"][] = "NOMBREDELPADRE";
$tdataReporte_de_Estudiantes[".editFields"][] = "NOMBREDELAMADRE";
$tdataReporte_de_Estudiantes[".editFields"][] = "NOMBREACUDIENTE";
$tdataReporte_de_Estudiantes[".editFields"][] = "HABILIDADES";
$tdataReporte_de_Estudiantes[".editFields"][] = "LIMITACIONES";
$tdataReporte_de_Estudiantes[".editFields"][] = "DOCENTEACARGO";
$tdataReporte_de_Estudiantes[".editFields"][] = "FOTODEPERFIL";

$tdataReporte_de_Estudiantes[".inlineEditFields"] = array();
$tdataReporte_de_Estudiantes[".inlineEditFields"][] = "NOMBRE";
$tdataReporte_de_Estudiantes[".inlineEditFields"][] = "FECHANACIMIENTO";
$tdataReporte_de_Estudiantes[".inlineEditFields"][] = "DIRECCION";
$tdataReporte_de_Estudiantes[".inlineEditFields"][] = "TELEFONO";
$tdataReporte_de_Estudiantes[".inlineEditFields"][] = "DIAGNOSTICO";
$tdataReporte_de_Estudiantes[".inlineEditFields"][] = "NOMBREDELPADRE";
$tdataReporte_de_Estudiantes[".inlineEditFields"][] = "NOMBREDELAMADRE";
$tdataReporte_de_Estudiantes[".inlineEditFields"][] = "NOMBREACUDIENTE";
$tdataReporte_de_Estudiantes[".inlineEditFields"][] = "HABILIDADES";
$tdataReporte_de_Estudiantes[".inlineEditFields"][] = "LIMITACIONES";
$tdataReporte_de_Estudiantes[".inlineEditFields"][] = "DOCENTEACARGO";
$tdataReporte_de_Estudiantes[".inlineEditFields"][] = "FOTODEPERFIL";

$tdataReporte_de_Estudiantes[".updateSelectedFields"] = array();
$tdataReporte_de_Estudiantes[".updateSelectedFields"][] = "NOMBRE";
$tdataReporte_de_Estudiantes[".updateSelectedFields"][] = "FECHANACIMIENTO";
$tdataReporte_de_Estudiantes[".updateSelectedFields"][] = "DIRECCION";
$tdataReporte_de_Estudiantes[".updateSelectedFields"][] = "TELEFONO";
$tdataReporte_de_Estudiantes[".updateSelectedFields"][] = "DIAGNOSTICO";
$tdataReporte_de_Estudiantes[".updateSelectedFields"][] = "NOMBREDELPADRE";
$tdataReporte_de_Estudiantes[".updateSelectedFields"][] = "NOMBREDELAMADRE";
$tdataReporte_de_Estudiantes[".updateSelectedFields"][] = "NOMBREACUDIENTE";
$tdataReporte_de_Estudiantes[".updateSelectedFields"][] = "HABILIDADES";
$tdataReporte_de_Estudiantes[".updateSelectedFields"][] = "LIMITACIONES";
$tdataReporte_de_Estudiantes[".updateSelectedFields"][] = "DOCENTEACARGO";
$tdataReporte_de_Estudiantes[".updateSelectedFields"][] = "FOTODEPERFIL";


$tdataReporte_de_Estudiantes[".exportFields"] = array();
$tdataReporte_de_Estudiantes[".exportFields"][] = "ID_ESTUDIANTE";
$tdataReporte_de_Estudiantes[".exportFields"][] = "NOMBRE";
$tdataReporte_de_Estudiantes[".exportFields"][] = "FECHANACIMIENTO";
$tdataReporte_de_Estudiantes[".exportFields"][] = "DIRECCION";
$tdataReporte_de_Estudiantes[".exportFields"][] = "TELEFONO";
$tdataReporte_de_Estudiantes[".exportFields"][] = "DIAGNOSTICO";
$tdataReporte_de_Estudiantes[".exportFields"][] = "NOMBREDELPADRE";
$tdataReporte_de_Estudiantes[".exportFields"][] = "NOMBREDELAMADRE";
$tdataReporte_de_Estudiantes[".exportFields"][] = "NOMBREACUDIENTE";
$tdataReporte_de_Estudiantes[".exportFields"][] = "HABILIDADES";
$tdataReporte_de_Estudiantes[".exportFields"][] = "LIMITACIONES";
$tdataReporte_de_Estudiantes[".exportFields"][] = "DOCENTEACARGO";
$tdataReporte_de_Estudiantes[".exportFields"][] = "FOTODEPERFIL";

$tdataReporte_de_Estudiantes[".importFields"] = array();
$tdataReporte_de_Estudiantes[".importFields"][] = "ID_ESTUDIANTE";
$tdataReporte_de_Estudiantes[".importFields"][] = "NOMBRE";
$tdataReporte_de_Estudiantes[".importFields"][] = "FECHANACIMIENTO";
$tdataReporte_de_Estudiantes[".importFields"][] = "DIRECCION";
$tdataReporte_de_Estudiantes[".importFields"][] = "TELEFONO";
$tdataReporte_de_Estudiantes[".importFields"][] = "DIAGNOSTICO";
$tdataReporte_de_Estudiantes[".importFields"][] = "NOMBREDELPADRE";
$tdataReporte_de_Estudiantes[".importFields"][] = "NOMBREDELAMADRE";
$tdataReporte_de_Estudiantes[".importFields"][] = "NOMBREACUDIENTE";
$tdataReporte_de_Estudiantes[".importFields"][] = "HABILIDADES";
$tdataReporte_de_Estudiantes[".importFields"][] = "LIMITACIONES";
$tdataReporte_de_Estudiantes[".importFields"][] = "DOCENTEACARGO";
$tdataReporte_de_Estudiantes[".importFields"][] = "FOTODEPERFIL";

$tdataReporte_de_Estudiantes[".printFields"] = array();
$tdataReporte_de_Estudiantes[".printFields"][] = "ID_ESTUDIANTE";
$tdataReporte_de_Estudiantes[".printFields"][] = "NOMBRE";
$tdataReporte_de_Estudiantes[".printFields"][] = "FECHANACIMIENTO";
$tdataReporte_de_Estudiantes[".printFields"][] = "DIRECCION";
$tdataReporte_de_Estudiantes[".printFields"][] = "TELEFONO";
$tdataReporte_de_Estudiantes[".printFields"][] = "DIAGNOSTICO";
$tdataReporte_de_Estudiantes[".printFields"][] = "NOMBREDELPADRE";
$tdataReporte_de_Estudiantes[".printFields"][] = "NOMBREDELAMADRE";
$tdataReporte_de_Estudiantes[".printFields"][] = "NOMBREACUDIENTE";
$tdataReporte_de_Estudiantes[".printFields"][] = "HABILIDADES";
$tdataReporte_de_Estudiantes[".printFields"][] = "LIMITACIONES";
$tdataReporte_de_Estudiantes[".printFields"][] = "DOCENTEACARGO";
$tdataReporte_de_Estudiantes[".printFields"][] = "FOTODEPERFIL";


//	ID_ESTUDIANTE
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "ID_ESTUDIANTE";
	$fdata["GoodName"] = "ID_ESTUDIANTE";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("Reporte_de_Estudiantes","ID_ESTUDIANTE");
	$fdata["FieldType"] = 3;

		// report field settings
					// end of report field settings

		$fdata["AutoInc"] = true;

	
			
		$fdata["bListPage"] = true;

	
	
	
	
	

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "ID_ESTUDIANTE";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "ID_ESTUDIANTE";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


		$edata["IsRequired"] = true;

	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataReporte_de_Estudiantes["ID_ESTUDIANTE"] = $fdata;
//	NOMBRE
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "NOMBRE";
	$fdata["GoodName"] = "NOMBRE";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("Reporte_de_Estudiantes","NOMBRE");
	$fdata["FieldType"] = 200;

		// report field settings
					// end of report field settings

	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "NOMBRE";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "NOMBRE";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataReporte_de_Estudiantes["NOMBRE"] = $fdata;
//	FECHANACIMIENTO
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "FECHANACIMIENTO";
	$fdata["GoodName"] = "FECHANACIMIENTO";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("Reporte_de_Estudiantes","FECHANACIMIENTO");
	$fdata["FieldType"] = 135;

		// report field settings
					// end of report field settings

	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "FECHANACIMIENTO";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "FECHANACIMIENTO";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Short Date");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Date");

		$edata["ShowTime"] = true;

	
		
	


		$edata["IsRequired"] = true;

	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
		$edata["DateEditType"] = 13;
	$edata["InitialYearFactor"] = 100;
	$edata["LastYearFactor"] = 10;

	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between", EMPTY_SEARCH, NOT_EMPTY );
// the end of search options settings




	$tdataReporte_de_Estudiantes["FECHANACIMIENTO"] = $fdata;
//	DIRECCION
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "DIRECCION";
	$fdata["GoodName"] = "DIRECCION";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("Reporte_de_Estudiantes","DIRECCION");
	$fdata["FieldType"] = 200;

		// report field settings
					// end of report field settings

	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "DIRECCION";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "DIRECCION";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataReporte_de_Estudiantes["DIRECCION"] = $fdata;
//	TELEFONO
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "TELEFONO";
	$fdata["GoodName"] = "TELEFONO";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("Reporte_de_Estudiantes","TELEFONO");
	$fdata["FieldType"] = 3;

		// report field settings
					// end of report field settings

	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "TELEFONO";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "TELEFONO";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


		$edata["IsRequired"] = true;

	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataReporte_de_Estudiantes["TELEFONO"] = $fdata;
//	DIAGNOSTICO
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "DIAGNOSTICO";
	$fdata["GoodName"] = "DIAGNOSTICO";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("Reporte_de_Estudiantes","DIAGNOSTICO");
	$fdata["FieldType"] = 200;

		// report field settings
		$fdata["isTotalMin"] = true;
		$fdata["isTotalAvg"] = true;
		$fdata["isTotalMax"] = true;
		$fdata["isTotalSum"] = true;
	// end of report field settings

	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "DIAGNOSTICO";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "DIAGNOSTICO";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataReporte_de_Estudiantes["DIAGNOSTICO"] = $fdata;
//	NOMBREDELPADRE
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "NOMBREDELPADRE";
	$fdata["GoodName"] = "NOMBREDELPADRE";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("Reporte_de_Estudiantes","NOMBREDELPADRE");
	$fdata["FieldType"] = 200;

		// report field settings
					// end of report field settings

	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "NOMBREDELPADRE";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "NOMBREDELPADRE";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataReporte_de_Estudiantes["NOMBREDELPADRE"] = $fdata;
//	NOMBREDELAMADRE
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 8;
	$fdata["strName"] = "NOMBREDELAMADRE";
	$fdata["GoodName"] = "NOMBREDELAMADRE";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("Reporte_de_Estudiantes","NOMBREDELAMADRE");
	$fdata["FieldType"] = 200;

		// report field settings
					// end of report field settings

	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "NOMBREDELAMADRE";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "NOMBREDELAMADRE";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataReporte_de_Estudiantes["NOMBREDELAMADRE"] = $fdata;
//	NOMBREACUDIENTE
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 9;
	$fdata["strName"] = "NOMBREACUDIENTE";
	$fdata["GoodName"] = "NOMBREACUDIENTE";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("Reporte_de_Estudiantes","NOMBREACUDIENTE");
	$fdata["FieldType"] = 200;

		// report field settings
					// end of report field settings

	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "NOMBREACUDIENTE";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "NOMBREACUDIENTE";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataReporte_de_Estudiantes["NOMBREACUDIENTE"] = $fdata;
//	HABILIDADES
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 10;
	$fdata["strName"] = "HABILIDADES";
	$fdata["GoodName"] = "HABILIDADES";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("Reporte_de_Estudiantes","HABILIDADES");
	$fdata["FieldType"] = 200;

		// report field settings
		$fdata["isTotalMin"] = true;
		$fdata["isTotalAvg"] = true;
		$fdata["isTotalMax"] = true;
		$fdata["isTotalSum"] = true;
	// end of report field settings

	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "HABILIDADES";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "HABILIDADES";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataReporte_de_Estudiantes["HABILIDADES"] = $fdata;
//	LIMITACIONES
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 11;
	$fdata["strName"] = "LIMITACIONES";
	$fdata["GoodName"] = "LIMITACIONES";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("Reporte_de_Estudiantes","LIMITACIONES");
	$fdata["FieldType"] = 200;

		// report field settings
		$fdata["isTotalMin"] = true;
		$fdata["isTotalAvg"] = true;
		$fdata["isTotalMax"] = true;
		$fdata["isTotalSum"] = true;
	// end of report field settings

	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "LIMITACIONES";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "LIMITACIONES";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataReporte_de_Estudiantes["LIMITACIONES"] = $fdata;
//	DOCENTEACARGO
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 12;
	$fdata["strName"] = "DOCENTEACARGO";
	$fdata["GoodName"] = "DOCENTEACARGO";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("Reporte_de_Estudiantes","DOCENTEACARGO");
	$fdata["FieldType"] = 200;

		// report field settings
					// end of report field settings

	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "DOCENTEACARGO";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "DOCENTEACARGO";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataReporte_de_Estudiantes["DOCENTEACARGO"] = $fdata;
//	FOTODEPERFIL
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 13;
	$fdata["strName"] = "FOTODEPERFIL";
	$fdata["GoodName"] = "FOTODEPERFIL";
	$fdata["ownerTable"] = "estudiantes";
	$fdata["Label"] = GetFieldLabel("Reporte_de_Estudiantes","FOTODEPERFIL");
	$fdata["FieldType"] = 200;

		// report field settings
					// end of report field settings

	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bUpdateSelected"] = true;


		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "FOTODEPERFIL";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "FOTODEPERFIL";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

		
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	
		
	


	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=300";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataReporte_de_Estudiantes["FOTODEPERFIL"] = $fdata;


$tables_data["Reporte de Estudiantes"]=&$tdataReporte_de_Estudiantes;
$field_labels["Reporte_de_Estudiantes"] = &$fieldLabelsReporte_de_Estudiantes;
$fieldToolTips["Reporte_de_Estudiantes"] = &$fieldToolTipsReporte_de_Estudiantes;
$placeHolders["Reporte_de_Estudiantes"] = &$placeHoldersReporte_de_Estudiantes;
$page_titles["Reporte_de_Estudiantes"] = &$pageTitlesReporte_de_Estudiantes;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["Reporte de Estudiantes"] = array();

// tables which are master tables for current table (detail)
$masterTablesData["Reporte de Estudiantes"] = array();


// -----------------end  prepare master-details data arrays ------------------------------//

require_once(getabspath("classes/sql.php"));










function createSqlQuery_Reporte_de_Estudiantes()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "ID_ESTUDIANTE,  	NOMBRE,  	FECHANACIMIENTO,  	DIRECCION,  	TELEFONO,  	DIAGNOSTICO,  	NOMBREDELPADRE,  	NOMBREDELAMADRE,  	NOMBREACUDIENTE,  	HABILIDADES,  	LIMITACIONES,  	DOCENTEACARGO,  	FOTODEPERFIL";
$proto0["m_strFrom"] = "FROM estudiantes";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "ID_ESTUDIANTE",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "Reporte de Estudiantes"
));

$proto6["m_sql"] = "ID_ESTUDIANTE";
$proto6["m_srcTableName"] = "Reporte de Estudiantes";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "NOMBRE",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "Reporte de Estudiantes"
));

$proto8["m_sql"] = "NOMBRE";
$proto8["m_srcTableName"] = "Reporte de Estudiantes";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "FECHANACIMIENTO",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "Reporte de Estudiantes"
));

$proto10["m_sql"] = "FECHANACIMIENTO";
$proto10["m_srcTableName"] = "Reporte de Estudiantes";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "DIRECCION",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "Reporte de Estudiantes"
));

$proto12["m_sql"] = "DIRECCION";
$proto12["m_srcTableName"] = "Reporte de Estudiantes";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "TELEFONO",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "Reporte de Estudiantes"
));

$proto14["m_sql"] = "TELEFONO";
$proto14["m_srcTableName"] = "Reporte de Estudiantes";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
						$proto16=array();
			$obj = new SQLField(array(
	"m_strName" => "DIAGNOSTICO",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "Reporte de Estudiantes"
));

$proto16["m_sql"] = "DIAGNOSTICO";
$proto16["m_srcTableName"] = "Reporte de Estudiantes";
$proto16["m_expr"]=$obj;
$proto16["m_alias"] = "";
$obj = new SQLFieldListItem($proto16);

$proto0["m_fieldlist"][]=$obj;
						$proto18=array();
			$obj = new SQLField(array(
	"m_strName" => "NOMBREDELPADRE",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "Reporte de Estudiantes"
));

$proto18["m_sql"] = "NOMBREDELPADRE";
$proto18["m_srcTableName"] = "Reporte de Estudiantes";
$proto18["m_expr"]=$obj;
$proto18["m_alias"] = "";
$obj = new SQLFieldListItem($proto18);

$proto0["m_fieldlist"][]=$obj;
						$proto20=array();
			$obj = new SQLField(array(
	"m_strName" => "NOMBREDELAMADRE",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "Reporte de Estudiantes"
));

$proto20["m_sql"] = "NOMBREDELAMADRE";
$proto20["m_srcTableName"] = "Reporte de Estudiantes";
$proto20["m_expr"]=$obj;
$proto20["m_alias"] = "";
$obj = new SQLFieldListItem($proto20);

$proto0["m_fieldlist"][]=$obj;
						$proto22=array();
			$obj = new SQLField(array(
	"m_strName" => "NOMBREACUDIENTE",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "Reporte de Estudiantes"
));

$proto22["m_sql"] = "NOMBREACUDIENTE";
$proto22["m_srcTableName"] = "Reporte de Estudiantes";
$proto22["m_expr"]=$obj;
$proto22["m_alias"] = "";
$obj = new SQLFieldListItem($proto22);

$proto0["m_fieldlist"][]=$obj;
						$proto24=array();
			$obj = new SQLField(array(
	"m_strName" => "HABILIDADES",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "Reporte de Estudiantes"
));

$proto24["m_sql"] = "HABILIDADES";
$proto24["m_srcTableName"] = "Reporte de Estudiantes";
$proto24["m_expr"]=$obj;
$proto24["m_alias"] = "";
$obj = new SQLFieldListItem($proto24);

$proto0["m_fieldlist"][]=$obj;
						$proto26=array();
			$obj = new SQLField(array(
	"m_strName" => "LIMITACIONES",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "Reporte de Estudiantes"
));

$proto26["m_sql"] = "LIMITACIONES";
$proto26["m_srcTableName"] = "Reporte de Estudiantes";
$proto26["m_expr"]=$obj;
$proto26["m_alias"] = "";
$obj = new SQLFieldListItem($proto26);

$proto0["m_fieldlist"][]=$obj;
						$proto28=array();
			$obj = new SQLField(array(
	"m_strName" => "DOCENTEACARGO",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "Reporte de Estudiantes"
));

$proto28["m_sql"] = "DOCENTEACARGO";
$proto28["m_srcTableName"] = "Reporte de Estudiantes";
$proto28["m_expr"]=$obj;
$proto28["m_alias"] = "";
$obj = new SQLFieldListItem($proto28);

$proto0["m_fieldlist"][]=$obj;
						$proto30=array();
			$obj = new SQLField(array(
	"m_strName" => "FOTODEPERFIL",
	"m_strTable" => "estudiantes",
	"m_srcTableName" => "Reporte de Estudiantes"
));

$proto30["m_sql"] = "FOTODEPERFIL";
$proto30["m_srcTableName"] = "Reporte de Estudiantes";
$proto30["m_expr"]=$obj;
$proto30["m_alias"] = "";
$obj = new SQLFieldListItem($proto30);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto32=array();
$proto32["m_link"] = "SQLL_MAIN";
			$proto33=array();
$proto33["m_strName"] = "estudiantes";
$proto33["m_srcTableName"] = "Reporte de Estudiantes";
$proto33["m_columns"] = array();
$proto33["m_columns"][] = "ID_ESTUDIANTE";
$proto33["m_columns"][] = "NOMBRE";
$proto33["m_columns"][] = "FECHANACIMIENTO";
$proto33["m_columns"][] = "DIRECCION";
$proto33["m_columns"][] = "TELEFONO";
$proto33["m_columns"][] = "DIAGNOSTICO";
$proto33["m_columns"][] = "NOMBREDELPADRE";
$proto33["m_columns"][] = "NOMBREDELAMADRE";
$proto33["m_columns"][] = "NOMBREACUDIENTE";
$proto33["m_columns"][] = "HABILIDADES";
$proto33["m_columns"][] = "LIMITACIONES";
$proto33["m_columns"][] = "DOCENTEACARGO";
$proto33["m_columns"][] = "FOTODEPERFIL";
$obj = new SQLTable($proto33);

$proto32["m_table"] = $obj;
$proto32["m_sql"] = "estudiantes";
$proto32["m_alias"] = "";
$proto32["m_srcTableName"] = "Reporte de Estudiantes";
$proto34=array();
$proto34["m_sql"] = "";
$proto34["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto34["m_column"]=$obj;
$proto34["m_contained"] = array();
$proto34["m_strCase"] = "";
$proto34["m_havingmode"] = false;
$proto34["m_inBrackets"] = false;
$proto34["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto34);

$proto32["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto32);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="Reporte de Estudiantes";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_Reporte_de_Estudiantes = createSqlQuery_Reporte_de_Estudiantes();


	
		;

													

$tdataReporte_de_Estudiantes[".sqlquery"] = $queryData_Reporte_de_Estudiantes;

$tableEvents["Reporte de Estudiantes"] = new eventsBase;
$tdataReporte_de_Estudiantes[".hasEvents"] = false;

?>